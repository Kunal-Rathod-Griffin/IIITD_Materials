#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

sem_t room;
sem_t chopstick[5];
sem_t souce_bowl;

void * philosopher(void *);
void eat(int a, int b);
void picking_forks(int a, int b);
void putting_forks(int a, int b);

int main()
{
	int i,a[5];
	pthread_t tid[5];
	
	sem_init(&room,0,4);
    sem_init(&souce_bowl, 0, 4);

	for(i=0;i<5;i++)
		sem_init(&chopstick[i],0,1);
		
	for(i=0;i<5;i++){
		a[i]=i;
		pthread_create(&tid[i],NULL,philosopher,(void *)&a[i]);
	}
	for(i=0;i<5;i++)
		pthread_join(tid[i],NULL);
}

void * philosopher(void * num)
{
	int phil=*(int *)num;

	sem_wait(&room);
	printf("\nPhilosopher %d has entered room",phil);
	int k = (phil + 1)%5;

	picking_forks(phil, k);
	
	eat(phil, k);
	
	putting_forks(phil, k);

	sem_post(&room);
    printf("\nout of the rrom");

}

void picking_forks(int a, int b){
	sem_wait(&chopstick[a]);
    printf("\npicked up chopstick %d", a);
    
	sem_wait(&chopstick[b]);
    printf("\npicked up chopstick %d", b);
    
    sem_wait(&souce_bowl);
    printf("\npicked up souce bowl");
}

void putting_forks(int a, int b)
{
    sem_post(&souce_bowl);
    printf("\nputting souce bowl");
    
    
	sem_post(&chopstick[b]);
    printf("\nputting right fork %d", b);

    
	sem_post(&chopstick[a]);
    printf("\nputting left fork %d", a);

}
void eat(int phil, int k)
{
	printf("\nPhilosopher %d is eating",phil);
	sleep(2);
	printf("\nPhilosopher %d has finished eating",phil);
    
}
