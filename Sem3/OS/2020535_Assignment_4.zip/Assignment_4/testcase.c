#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

void P(){
    int fd = open("/dev/urandom", O_RDONLY);
    
    if(fd==-1){
        printf("falied to read the file\n");
        return;
    }


    long input;
    
    read(fd, &input, sizeof input);
    
    int systemcall_writer = syscall(451, input);
    
    if(systemcall_writer == -1){
        printf("writer() system call failed\n");
        return;
    }
    printf("The Enqueued number is %ld\n", input);
}

void C(){
    long sytemcall_reader = syscall(452);
    
    if(sytemcall_reader == -1){
        printf("reader() system call failed\n");
        return;
    }

    printf("The Dequeued number is %ld\n", sytemcall_reader);
}

int main(){


    printf("Enqueuing the numbers\n");

    P();
    P();

    
    printf("Dequeuing the number\n");
    C();
    C();
    
    printf("Exit\n");
}

