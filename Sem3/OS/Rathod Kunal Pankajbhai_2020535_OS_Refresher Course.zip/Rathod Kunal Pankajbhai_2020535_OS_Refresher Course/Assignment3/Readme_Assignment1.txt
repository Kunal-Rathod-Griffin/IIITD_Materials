﻿(the text in red is user input)


Problem 1:


* Run the command $make 1st 
* There will be a file named “ass1_1”, which is compiled file. 
* You will have to make two text files in the same directory as a source and destination file. 
* Now run $./ass1_1 in terminal
Inputs: (the text in red is user input)


Enter source file name: text1.txt (source file)
Enter destination file name: text2.txt (destination file)


Press Enter to end the program.  


Problem 2:


* Run $make 2nd
* Now run $./ass1_2 to run the compiled file
* The output will be shown.


Problem 3:
* Run $make 3rd
* Now run $./ass1_3 to run the compiled file


Inputs:


Enter the value of variable 1: 5
Enter the value of variable 2: 10
Variable 1 = 10
Variable 2 = 5


Enter the size of your arrays: 3
Enter the elements of array 1: 
1
2
3
Enter the elements of array 2: 
4
5
6
Elements of an array 1: 4 5 6 
Elements of an array 2: 1 2 3 


Problem 4:


* Run $make 4th
* Now run $./ass1_4 to run the compiled file
* 

Input:


Enter the String to get reversed
kunal rathod p


Reversed string is 
p dohtar lanuk


Problem 5:
* Run $make 5th
* Now run $./ass1_5


Input:
Enter the size of an array: 3
Enter the elements of an array: 
1
2
3
Enter the element for searching: 2
Element found at index 1