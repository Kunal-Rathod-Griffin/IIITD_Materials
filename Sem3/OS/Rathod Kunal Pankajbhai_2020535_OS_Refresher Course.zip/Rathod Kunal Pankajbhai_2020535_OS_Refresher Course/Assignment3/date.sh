#!/usr/bin/env bash
day=$1
month=$2
year=$3
 
cal $2 $3