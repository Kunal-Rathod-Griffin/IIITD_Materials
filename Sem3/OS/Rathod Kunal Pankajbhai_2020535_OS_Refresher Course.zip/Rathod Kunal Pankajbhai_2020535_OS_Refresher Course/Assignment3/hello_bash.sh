#!/bin/bash


add () {
    echo $(( $1 + $2 ))
}

sub () {
    echo $(( $1 - $2 ))
}

mul () {
    echo $(( $1 * $2 ))
}

div () {
    if [ $2 -ne 0 ]
    then
        echo  $(( $1 / $2 ))
    else
        echo "Division by 0 not valid"
    fi
}

exp () {
    if [ $2 -ne 0 ]
    then
        p=$(( $2 - 1 ))
        x=$( exp $1 $p )
        (( x *= $1 ))
        echo $x
        
    else
        echo 1
    fi
}

inp=("$@")

if [ "$1" == "add" ]

then
    x=0

    for (( i=1; i < $# ; i++ )); do
        x=$( add $x ${inp[i]})
    done
    echo "Output on addition:" $x      
elif [ "$1" == "sub" ]

then
    x=${inp[1]}

    for (( i=2; i < $# ; i++ )); do
        x=$( sub $x ${inp[i]})
    done 
    echo "Output on subtraction:" $x
   
elif [ "$1" == "mul" ]

then
    x=1

    for (( i=1; i < $# ; i++ )); do
        x=$( mul $x ${inp[i]})
    done 
    echo "Output on multiplication:" $x
    
elif [ "$1" == "div" ]

then
    x=${inp[1]}

    for (( i=2; i < $# ; i++ )); do
        x=$( div $x ${inp[i]})
    done 
    echo "Output on division:" $x
   
elif [ "$1" == "exp" ]

then
    x=${inp[1]}
    
    for (( i=2; i < $# ; i++ )); do
        x=$( exp $x ${inp[i]})
    done 
    echo "Output on taking exponent:" $x
    
fi