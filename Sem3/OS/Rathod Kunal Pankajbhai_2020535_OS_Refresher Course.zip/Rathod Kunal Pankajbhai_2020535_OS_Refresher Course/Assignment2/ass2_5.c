#include <stdio.h>
#include <stdlib.h>
#include<string.h>  


void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
  
void bubbleSort(int arr[], int n)
{
   int i, j;
   for (i = 0; i < n-1; i++)     
 
       for (j = 0; j < n-i-1; j++)
           if (arr[j] > arr[j+1])
              swap(&arr[j], &arr[j+1]);
}

void selectionSort(int arr[], int n)
{
    int i, j, min_idx;
 
    for (i = 0; i < n-1; i++)
    {
        min_idx = i;
        for (j = i+1; j < n; j++)
          if (arr[j] < arr[min_idx])
            min_idx = j;
 
        swap(&arr[min_idx], &arr[i]);
    }
}

void printArray(int arr[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
int main()
{
    printf("enter the size of an array: ");
    int size;
    scanf("%d\n",&size);
    
    int arr[size];

    for(int i =0; i<size; i++)
    {
        scanf("%d", &arr[i]);
    }
    
    
    
    
    
    int n = sizeof(arr)/sizeof(arr[0]);
    char soritng[50];

    printf("Which sorting do you want to use? selection/bubble: \n");
    
    char str[20];

    scanf("%s",str);
    
    printf("%s = sorintg\n", str);
    
    if(strcmp(str, "bubble") == 0){
        bubbleSort(arr, n);
    }else if( strcmp(str, "selection") == 0 ){
        selectionSort(arr, n);
    } else{
        printf("----------\n");
    }

    printf("Sorted array: \n");
    printArray(arr, n);
    return 0;
}