﻿Text in red is user input.
Problem 2:


Problem 2a:
* Run $make ass2_2a
* Now run $./ass2_2a
In the terminal during input you have a menu with 4 items. Add, search, display all and exit.


So you can add a student with entering choice 1, name must be of one word only. 
You can search the student with his/her roll number by entering choice 2. 
Display all the students entering choice 3.
Exit with 0.


Inputs:
1 to insert student details
2 to search for student details
3 to display all student details
0 to exit
Enter Choice: 1
Enter roll number: 2020535
Enter name: kunal
year: 2020


Enter Choice: 1
Enter roll number: 2020536
Enter name: rathod
year: 2021


Enter Choice: 2
Enter roll number to search: 2020535
Roll Number: 2020535
Name: kunal
year: 0


Enter Choice: 3
Roll Number: 2020536
Name: rathod
year: 0
Roll Number: 2020535
Name: kunal
year: 0


Enter Choice: 0




Problem 2b:
* Run $make ass2_2b
* Now run $./ass2_2b


Input is completely similar to problem 2a. Only difference is in implementation. 


Problem 2c:


* Run $make ass2_2c
* Now run $./ass2_2c


Here you have a menu option to do different operations on the stack. The DATA of the stack is in integers numbers only.
You can do different operations by entering your choice according to the given menu.


Inputs:
1 - Push
 2 - Pop
 3 - Top
 4 - Empty
 5 - Exit
 6 - Dipslay
 7 - Stack Count
 8 - Destroy stack
 Enter choice : 1
Enter data : 0


 Enter choice : 1
Enter data : 1


 Enter choice : 1
Enter data : 2


 Enter choice : 1
Enter data : 3


 Enter choice : 7


 No. of elements in stack : 4
 Enter choice : 6
3 2 1 0 
 Enter choice : 2


 Popped value : 3
 Enter choice : 4


 Stack is not empty with 3 elements
 Enter choice : 5


Problem 3:
* Run $make ass2_3
* Now run $./ass2_3




Inputs:
Enter num 1: 2
Enter num 2: 1
2 + 1 = 3
2 - 1 = 1
2 / 1 = 2.00
2 * 1 = 2
2 ^ 1 = 2


Problem 5:
* Run $make ass2_5
* Now run $./ass2_5
In the inputs you can type “selection” or “bubble” to do that sorting.


Inputs:
enter the size of an arryL: 3
1
2
3
Which sorting do you want to use? selection/bubble: 
bubble
bubble = sorintg
Sorted array: 
1 2 3