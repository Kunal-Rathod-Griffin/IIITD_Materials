#include<stdlib.h>
#include<string.h>
#include<stdio.h>

struct Student
{
    int rollnumber;
    char name[100];
    int year;
    struct Student *next;

    
}* head;

void insert(int rollnumber, char* name,  int year)
{
    
    struct Student * student = (struct Student *) malloc(sizeof(struct Student));
    student->rollnumber = rollnumber;
    strcpy(student->name, name);
    student->next = NULL;
    
    if(head==NULL){
        // if head is NULL
        // set student as the new head
        head = student;
    }
    else{
        // if list is not empty
        // insert student in beginning of head
        student->next = head;
        head = student;
    }
    
}

void search(int rollnumber)
{
    struct Student * temp = head;
    while(temp!=NULL){
        if(temp->rollnumber==rollnumber){
            printf("Roll Number: %d\n", temp->rollnumber);
            printf("Name: %s\n", temp->name);
            printf("year: %d\n", temp->year);

            return;
        }
        temp = temp->next;
    }
    printf("Student with roll number %d is not found !!!\n", rollnumber);
}

void display()
{
    struct Student * temp = head;
    while(temp!=NULL){
        
        printf("Roll Number: %d\n", temp->rollnumber);
        printf("Name: %s\n", temp->name);
        printf("year: %d\n", temp->year);

        temp = temp->next;
        
    }
}

int main()
{
    head = NULL;
    int choice;
    char name[100];
    int rollnumber;
    int year;


    printf("1 to insert student details\n2 to search for student details\n3 to display all student details\n0 to exit");
    do
    {
        printf("\nEnter Choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
                printf("Enter roll number: ");
                scanf("%d", &rollnumber);
                printf("Enter name: ");
                scanf("%s", name);
                printf("year: ");
                scanf("%d", &year);
                insert(rollnumber, name, year);
                break;
            case 2:
                printf("Enter roll number to search: ");
                scanf("%d", &rollnumber);
                search(rollnumber);
                break;
            case 3:
                display();
                break;
        }
        
    } while (choice != 0);
}