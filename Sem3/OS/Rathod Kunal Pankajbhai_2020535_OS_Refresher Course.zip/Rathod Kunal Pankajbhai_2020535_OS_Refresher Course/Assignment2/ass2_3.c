#include <stdio.h>
#include <math.h>


void add(int a, int b) {
	printf("%d + %d = %d\n",a,b,(a+b));
}
 

void sub(int a, int b) {
	printf("%d - %d = %d\n",a,b,(a-b));
}
void div(int a, int b) {
	printf("%d / %d = %.2f\n",a,b,((float)a/(float)b));
}
void mul(int a, int b) {
	printf("%d * %d = %d\n",a,b,(a*b));
}
void expp(int a, int b) {

	int bb = b;
	int aa = a;
	while(bb>1){
		aa = aa *a;
		bb = bb -1;
	}


	printf("%d ^ %d = %d\n",a,b,aa);
}

int main() {
	int i;
	
    int num1;
	int num2;


	typedef void (*type)(int, int); 
	type arr[] = {&add, &sub, &div, &mul, &expp};


	printf("Enter num 1: ");
	scanf("%d",&num1);
	
    printf("Enter num 2: ");
	scanf("%d",&num2);


	for (i = 0; i < 5; ++i){
		arr[i](num1, num2);
	}


	
	return 0;
}


