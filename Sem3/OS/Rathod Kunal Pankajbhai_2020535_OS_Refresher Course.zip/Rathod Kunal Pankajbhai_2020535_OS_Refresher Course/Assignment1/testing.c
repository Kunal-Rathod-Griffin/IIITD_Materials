#include <stdio.h>

int main()
{
    printf("hello there");

    printf("hello dear again");
}