#include <stdio.h>
#include <stdlib.h>

int binary_search( unsigned int arr[], unsigned int l, unsigned int k, unsigned int x )
{
    if(k>=1)
    {
        int middle = (l + k)/2;
        if(arr[middle] ==  x)
            return middle;
        if(arr[middle]>x)
            return binary_search(arr, 0, middle-1, x);
        else{
            return binary_search(arr, middle + 1, k, x);
        }
    }else{
        return -1;
    }
}
int main()
{
    unsigned int n, x;

    printf("Enter the size of an array: ");
    scanf("%d",&n);

    int arr[n];
    printf("Enter the elements of an array: \n");
    for(int i =0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }

    printf("Enter the element for searching: ");
    scanf("%d",&x);

    int a = binary_search(arr, 0, n-1, x);

    if(a==-1)
        printf("Element not found\n");
    else
        printf("Element found at index %d", a);

    
    return 0;
}