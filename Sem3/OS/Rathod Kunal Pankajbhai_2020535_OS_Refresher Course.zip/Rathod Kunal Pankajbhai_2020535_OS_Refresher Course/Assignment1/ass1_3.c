#include <stdio.h>
#include <stdlib.h>

void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

int main()
{
    printf("Enter the value of variable 1: ");
    int var1;
    scanf("%d",&var1);


    printf("Enter the value of variable 2: ");
    int var2;
    scanf("%d",&var2);

    swap(&var1, &var2);

    printf("Variable 1 = %d\n",var1);
    printf("Variable 2 = %d\n", var2);

    printf("Enter the size of your arrays: ");
    int size1;

    scanf("%d",&size1);
    int arr1[size1];

    printf("Enter the elemensts of array 1: \n");
    for(int i =0; i<size1; i++)
    {
        scanf("%d",&arr1[i]);
    }

    

    int arr2[size1];

    printf("Enter the elements of array 2: \n");
    for(int i =0; i<size1; i++)
    {
        scanf("%d",&arr2[i]);
    }

    for(int i =0; i< size1; i++)
    {
        swap(&arr1[i], &arr2[i]);

    }

    printf("Elements of an array 1: ");
    for(int i =0; i<size1; i++)
    {
        printf("%d ", arr1[i]);
    }
    printf("\n");

    printf("Elements of an array 2: ");
    for(int i =0; i<size1; i++)
    {
        printf("%d ", arr2[i]);
    }

    return 0;

}