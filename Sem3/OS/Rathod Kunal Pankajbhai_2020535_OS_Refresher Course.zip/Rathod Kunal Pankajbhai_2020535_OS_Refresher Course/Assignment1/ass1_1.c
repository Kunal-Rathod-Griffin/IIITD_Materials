#include<stdio.h>
#include<string.h>




int main() {
	char letter;
	char sourceFileName[100];
	char destinationFileName[100];


	FILE *fpSourceFile, *fpDestinationFile;


	printf("Enter source file name: ");
	scanf("%s",&sourceFileName);
	if((fpSourceFile = fopen(sourceFileName, "rb"))!=NULL){
		printf("Enter destination file name: ");
		scanf("%s",&destinationFileName);
		fpDestinationFile = fopen(destinationFileName, "wb");


		while(fread(&letter, 1, 1, fpSourceFile) == 1){
			fwrite(&letter, 1, 1, fpDestinationFile);
		}
		printf("\nThe file has been copied.\n");
		// Close The Files
		fclose(fpSourceFile);
		fclose(fpDestinationFile);
	}else{
		printf("\nThe file does not exist.\n");
	}




	getchar();
	getchar();
	return 0;
}