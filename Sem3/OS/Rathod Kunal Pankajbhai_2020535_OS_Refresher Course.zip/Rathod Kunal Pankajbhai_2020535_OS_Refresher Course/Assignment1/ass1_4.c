#include <stdlib.h>
#include <stdio.h>
 
void main()
{
    int k,n;
    printf("Enter the String to get reversed\n");
    char str[1000]; 
    scanf(" %[^\n]",str);
 

    int ii;
    for (ii = 0; str[ii] != '\0'; ++ii);
    n = ii;

    printf("\nReversed string is \n");
    for(k=n-1;k>=0;k--)
    {
       printf("%c",str[k]);
    }
    
}