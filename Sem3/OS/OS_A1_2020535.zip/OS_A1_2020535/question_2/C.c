#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

void C(){
    
    printf("End of program.\n");
    exit(0);
    
}