#include "C.c"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>


void B(uint64_t number){


    uint8_t byte[8];
    
    byte[0] = *((uint8_t*)&(number)+0 ); 
    byte[1] = *((uint8_t*)&(number)+1 ); 
    byte[2] = *((uint8_t*)&(number)+2 ); 
    byte[3] = *((uint8_t*)&(number)+3 ); 

    byte[4] = *((uint8_t*)&(number)+4 ); 
    byte[5] = *((uint8_t*)&(number)+5 ); 
    byte[6] = *((uint8_t*)&(number)+6 ); 
    byte[7] = *((uint8_t*)&(number)+7 ); 

    


    for(int i=0; i<8; i++){
        
        printf("byte %d = %d\n", i, byte[i]);

        char c = byte[i];

        char the_value[30];
        snprintf(the_value, 30, "ASCII of %d = %c\n", byte[i], c);
		write(1, the_value, strlen(the_value));

    }


    C();
}

