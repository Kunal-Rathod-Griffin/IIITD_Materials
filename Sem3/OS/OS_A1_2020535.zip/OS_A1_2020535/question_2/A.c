#include "B.c"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>




void A(){
    
    uint64_t number = 0x1234567891011123;
    B(number);
}

int main(){
    A();
    
}