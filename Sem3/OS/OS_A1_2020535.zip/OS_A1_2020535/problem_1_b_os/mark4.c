#define _GNU_SOURCE  
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>


int assi1, assi2, assi3, assi4, assi5, assi6, student_secA;

float average_1_A, average_2_A,average_3_A,average_4_A,average_5_A,average_6_A;
float average_1B, average_2B,average_3B,average_4B,average_5B,average_6B; 

void* section_B(void* arg){

    int  sz;
    int fd;

    char buffer[10000];

    fd = open("student_record.csv", O_RDONLY); 

    if(fd<0){
        perror("r1");
        pthread_exit(NULL);
    } 

    sz = read( fd, buffer, sizeof( buffer));
    if(sz<0){
        printf("failed in sz");

    }

    char *end_str;
    char *token = strtok_r(buffer, "\n", &end_str);

                while(token != NULL){

                
                // printf("each token:  %s\n", token);

        
                char *end_token;
                char *token2 = strtok_r(token, ",", &end_token);

                char arr[8][10000]; 
                int i =0;
                while(token2 != NULL)
                {
                    // printf("b = %s\n", token2);
                    strcpy(arr[i], token2);
                    token2 = strtok_r(NULL, ",", &end_token);
                    i++;
                }

                if(strcmp(arr[1], "A")){
                    // printf("%s\n", arr[1]);
                    // printf("%s\n", arr[0]);
                    assi1 += atoi(arr[2]);
                    assi2 += atoi(arr[3]);
                    assi3 += atoi(arr[4]);
                    assi4 += atoi(arr[5]);
                    assi5 += atoi(arr[6]);
                    assi6 += atoi(arr[7]);

                    student_secA+=1;
                }

                token = strtok_r(NULL, "\n", &end_str);

            }
            
            close(fd);

            int sz2;

            int fd2 = open("secA_threads.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd2 < 0)
            {
                perror("r1");
                exit(1);
            }
            
            // average_1 = assi1/student_secA;
            // int average_2 = assi2/student_secA;
            // int average_3 = assi3/student_secA;
            // int average_4 = assi4/student_secA;
            // int average_5 = assi5/student_secA;
            // int average_6 = assi6/student_secA;

             average_1_A = assi1/(float) student_secA;
             average_2_A = assi2/(float) student_secA;
             average_3_A = assi3/(float) student_secA;
             average_4_A = assi4/(float) student_secA;
             average_5_A = assi5/(float) student_secA;
             average_6_A = assi6/(float) student_secA;


            char av1[100];
            char av2[100];
            char av3[100];
            char av4[100];
            char av5[100];
            char av6[100];            


            sprintf(av1, "%f", average_1_A);
            sprintf(av2, "%f", average_2_A);
            sprintf(av3, "%f", average_3_A);
            sprintf(av4, "%f", average_4_A);
            sprintf(av5, "%f", average_5_A);
            sprintf(av6, "%f", average_6_A);

            sz2 = write(fd2, av1, strlen(av1));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av2, strlen(av2));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av3, strlen(av3));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av4, strlen(av4));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av5, strlen(av5));
           
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av6, strlen(av6));
           
            sz2 = write(fd2, "\n", strlen("\n"));

             write(1,"secB\n", strlen("secB\n"));
            write(1, av1, strlen(av1));
            write(1,"\n", strlen("\n"));
            write(1, av2, strlen(av2));
            write(1,"\n", strlen("\n"));
            write(1, av3, strlen(av3));
            write(1,"\n", strlen("\n"));
            write(1, av4, strlen(av4));
            write(1,"\n", strlen("\n"));
            write(1, av5, strlen(av5));
            write(1,"\n", strlen("\n"));
            write(1, av6, strlen(av6));
            write(1,"\n", strlen("\n"));
            write(1,"\n", strlen("\n"));
           
            pthread_exit(NULL);


}

int aassi1, aassi2, aassi3, aassi4, aassi5, aassi6, student_secB;

void* section_A(void* arg){

    sleep(1);
    int  sz;
    int fd;

    char buffer[10000];

    fd = open("student_record.csv", O_RDONLY); 

    if(fd<0){
        perror("r1");
        pthread_exit(NULL);
    } 

    sz = read( fd, buffer, sizeof( buffer));
    if(sz<0){
        printf("failed in sz");

    }

    char *end_str;
    char *token = strtok_r(buffer, "\n", &end_str);

                while(token != NULL){

                
                // printf("each token:  %s\n", token);

        
                char *end_token;
                char *token2 = strtok_r(token, ",", &end_token);

                char arr[8][10000]; 
                int i =0;
                while(token2 != NULL)
                {
                    // printf("b = %s\n", token2);
                    strcpy(arr[i], token2);
                    token2 = strtok_r(NULL, ",", &end_token);
                    i++;
                }

                if(strcmp(arr[1], "B")){
                    // printf("%s\n", arr[1]);
                    // printf("%s\n", arr[0]);
                    aassi1 += atoi(arr[2]);
                    aassi2 += atoi(arr[3]);
                    aassi3 += atoi(arr[4]);
                    aassi4 += atoi(arr[5]);
                    aassi5 += atoi(arr[6]);
                    aassi6 += atoi(arr[7]);

                    student_secB+=1;
                }

                token = strtok_r(NULL, "\n", &end_str);

            }
            
            close(fd);

            int sz2;

            int fd2 = open("secB_threads.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd2 < 0)
            {
                perror("r1");
                exit(1);
            }
            

             average_1B = aassi1/(float) student_secB;
             average_2B = aassi2/(float) student_secB;
             average_3B = aassi3/(float) student_secB;
             average_4B = aassi4/(float) student_secB;
             average_5B = aassi5/(float) student_secB;
             average_6B = aassi6/(float) student_secB;
            char av1[100];
            char av2[100];
            char av3[100];
            char av4[100];
            char av5[100];
            char av6[100];            


            sprintf(av1, "%f", average_1B);
            sprintf(av2, "%f", average_2B);
            sprintf(av3, "%f", average_3B);
            sprintf(av4, "%f", average_4B);
            sprintf(av5, "%f", average_5B);
            sprintf(av6, "%f", average_6B);

            sz2 = write(fd2, av1, strlen(av1));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av2, strlen(av2));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av3, strlen(av3));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av4, strlen(av4));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av5, strlen(av5));
           
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av6, strlen(av6));
           
            sz2 = write(fd2, "\n", strlen("\n"));

            write(1,"secA\n", strlen("secA\n"));
            write(1, av1, strlen(av1));
            write(1,"\n", strlen("\n"));
            write(1, av2, strlen(av2));
            write(1,"\n", strlen("\n"));
            write(1, av3, strlen(av3));
            write(1,"\n", strlen("\n"));
            write(1, av4, strlen(av4));
            write(1,"\n", strlen("\n"));
            write(1, av5, strlen(av5));
            write(1,"\n", strlen("\n"));
            write(1, av6, strlen(av6));
            
            
           
            pthread_exit(NULL);


}

int main(){

    pthread_t pid1;
    pthread_t pid2;

    int x,y;

    x = pthread_create(&pid1, NULL, &section_B, NULL);
    y = pthread_create(&pid2, NULL, &section_A, NULL); 

    if(x!=0){
        printf("error");

    } 
    if(y!= 0)
    {
        printf("error");
    }



    // write();
    

 



    pthread_join(pid1, NULL);
    pthread_join(pid2, NULL);

    int total_student = student_secA + student_secB;
    float totalA1 = (average_1_A*student_secA + average_1B*student_secB) / (float) total_student ;
    float totalA2 = (average_2_A*student_secA + average_2B*student_secB) /(float) total_student ;
    float totalA3 = (average_3_A*student_secA + average_3B*student_secB)/(float) total_student;
    float totalA4 = (average_4_A*student_secA + average_4B*student_secB)/(float) total_student;
    float totalA5 = (average_5_A*student_secA + average_5B*student_secB )/(float) total_student;
    float totalA6 = (average_6_A*student_secA + average_6B*student_secB )/(float) total_student;
    
    char t1[30], t2[30], t3[30], t4[30], t5[30], t6[30];

    sprintf(t1,"%f", totalA1);
    sprintf(t2,"%f", totalA2);
    sprintf(t3,"%f", totalA3);
    sprintf(t4,"%f", totalA4);
    sprintf(t5,"%f", totalA5);
    sprintf(t6,"%f", totalA6);


    write(1, "\n", strlen("\n"));
    write(1, "Assignment 1\n", strlen("Assignment 1\n"));
    write(1,t1, strlen(t1));
    write(1, "\n", strlen("\n"));

    write(1, "Assignment 2\n", strlen("Assignment 2\n"));
    write(1,t2, strlen(t2));
    write(1, "\n", strlen("\n"));

    write(1, "Assignment 3\n", strlen("Assignment 3\n"));
    write(1,t3, strlen(t3));
    write(1, "\n", strlen("\n"));

    write(1, "Assignment 4\n", strlen("Assignment 4\n"));
    write(1,t4, strlen(t4));
    write(1, "\n", strlen("\n"));

    write(1, "Assignment 5\n", strlen("Assignment 5\n"));
    write(1,t5, strlen(t5));
    write(1, "\n", strlen("\n"));

    write(1, "Assignment 6\n", strlen("Assignment 6\n"));
    write(1,t6, strlen(t6));
    write(1, "\n", strlen("\n"));



}