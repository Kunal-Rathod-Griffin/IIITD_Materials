#define _GNU_SOURCE  
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>



int main()
{
    int status;
    int pid = fork();

    if(pid<0){
        printf("failed to make a child process.");
        exit(1);
    }
    else if(pid==0){
        //child process
        int  sz;
        int fd;

        char buffer[10000];

        fd = open("student_record.csv", O_RDONLY); 

        if(fd<0){
            perror("r1");
            exit(1);
        } 

        sz = read( fd, buffer, sizeof( buffer));
        if(sz<0){
            printf("failed in sz");
        }

        char *end_str;
        char *token = strtok_r(buffer, "\n", &end_str);
        
        int assi1 =0;
        int assi2 =0;
        int assi3 =0;
        int assi4 =0;
        int assi5 =0;
        int assi6 =0;
        int student_secA= 0;


            while(token != NULL){

                
                // printf("each token:  %s\n", token);

        
                char *end_token;
                char *token2 = strtok_r(token, ",", &end_token);

                char arr[8][10000]; 
                int i =0;
                while(token2 != NULL)
                {
                    // printf("b = %s\n", token2);
                    strcpy(arr[i], token2);
                    token2 = strtok_r(NULL, ",", &end_token);
                    i++;
                }

                if(strcmp(arr[1], "A")){
                    // printf("%s\n", arr[1]);
                    // printf("%s\n", arr[0]);
                    assi1 += atoi(arr[2]);
                    assi2 += atoi(arr[3]);
                    assi3 += atoi(arr[4]);
                    assi4 += atoi(arr[5]);
                    assi5 += atoi(arr[6]);
                    assi6 += atoi(arr[7]);

                    student_secA+=1;
                }

                token = strtok_r(NULL, "\n", &end_str);

            }
            
            close(fd);

            int sz2;

            int fd2 = open("secA.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd2 < 0)
            {
                perror("r1");
                exit(1);
            }
            
            float average_1 = assi1/(float) student_secA;
            float average_2 = assi2/(float) student_secA;
            float average_3 = assi3/(float) student_secA;
            float average_4 = assi4/(float) student_secA;
            float average_5 = assi5/(float) student_secA;
            float average_6 = assi6/(float) student_secA;
            char av1[100];
            char av2[100];
            char av3[100];
            char av4[100];
            char av5[100];
            char av6[100];            


            sprintf(av1, "%f", average_1);
            sprintf(av2, "%f", average_2);
            sprintf(av3, "%f", average_3);
            sprintf(av4, "%f", average_4);
            sprintf(av5, "%f", average_5);
            sprintf(av6, "%f", average_6);

            sz2 = write(fd2, av1, strlen(av1));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av2, strlen(av2));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av3, strlen(av3));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av4, strlen(av4));
            
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av5, strlen(av5));
           
            sz2 = write(fd2, "\n", strlen("\n"));
            sz2 = write(fd2, av6, strlen(av6));
           
            sz2 = write(fd2, "\n", strlen("\n"));

            char a[] = "\nSection A: \n";
            
            write(STDOUT_FILENO,a, sizeof(a));

            char a1[] = "\nAssignment 1: ";
            
            write(STDOUT_FILENO,a1, sizeof(a1));
            
            write(1, av1, strlen(av1));
            write(1,"\n", strlen("\n"));

            char a2[] = "\nAssignment 2: ";
            
            write(STDOUT_FILENO,a2, sizeof(a2));

            write(1, av2, strlen(av2));
            write(1,"\n", strlen("\n"));

            char a3[] = "\nAssignment 3: ";
            
            write(STDOUT_FILENO,a3, sizeof(a3));


            write(1, av3, strlen(av3));
            write(1,"\n", strlen("\n"));

            char a4[] = "\nAssignment 4: ";
            
            write(STDOUT_FILENO,a4, sizeof(a4));

            write(1, av4, strlen(av4));
            write(1,"\n", strlen("\n"));

            char a5[] = "\nAssignment 5: ";
            
            write(STDOUT_FILENO,a5, sizeof(a5));

            write(1, av5, strlen(av5));
            write(1,"\n", strlen("\n"));

            char a6[] = "\nAssignment 6: ";
            
            write(STDOUT_FILENO,a6, sizeof(a6));

            write(1, av6, strlen(av6));
            write(1,"\n", strlen("\n"));
            write(1, "\n", strlen("\n"));

            close(fd2);
            // printf( "secA: Assignment_1 average marks: %d\n", assi1/student_secA);
            // printf("secA: Assignment_2 average marks: %d\n", assi2/student_secA);
            // printf("secA: Assignment_3 average marks: %d\n", assi3/student_secA);
            // printf("secA: Assignment_4 average marks: %d\n", assi4/student_secA);
            // printf("secA: Assignment_5 average marks: %d\n", assi5/student_secA);
            // printf("secA: Assignment_6 average marks: %d\n", assi6/student_secA);
            
            // printf("kunal kunal kunal\n");
            exit(0);
        
        } else if(pid>0){
        //parent


            sleep(2);
            int  sz;
            int fd;

            char buffer[10000];

            fd = open("student_record.csv", O_RDONLY); 

            if(fd<0){
                perror("r1");
                exit(1);
            } 

            sz = read( fd, buffer, sizeof( buffer));
            if(sz<0){
                printf("failed in sz");
            }

            char *end_str;
            char *token = strtok_r(buffer, "\n", &end_str);
            
            int assi1 =0;
            int assi2 =0;
            int assi3 =0;
            int assi4 =0;
            int assi5 =0;
            int assi6 =0;
            int student_secA= 0;


            while(token != NULL){

                
                // printf("each token:  %s\n", token);

        
                char *end_token;
                char *token2 = strtok_r(token, ",", &end_token);

                char arr[8][10000]; 
                int i =0;
                while(token2 != NULL)
                {
                    // printf("b = %s\n", token2);
                    strcpy(arr[i], token2);
                    token2 = strtok_r(NULL, ",", &end_token);
                    i++;
                }

                if(strcmp(arr[1], "B")){
                    // printf("%s\n", arr[1]);
                    // printf("%s\n", arr[0]);
                    assi1 += atoi(arr[2]);
                    assi2 += atoi(arr[3]);
                    assi3 += atoi(arr[4]);
                    assi4 += atoi(arr[5]);
                    assi5 += atoi(arr[6]);
                    assi6 += atoi(arr[7]);

                    student_secA+=1;
                }

                token = strtok_r(NULL, "\n", &end_str);

                }
                
                close(fd);

                int sz2;

                int fd2 = open("secB.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (fd2 < 0)
                {
                    perror("r1");
                    exit(1);
                }
                
                float average_1 = assi1/(float)  student_secA;
                float average_2 = assi2/(float)student_secA;
                float average_3 = assi3/(float)student_secA;
                float average_4 = assi4/(float)student_secA;
                float average_5 = assi5/(float)student_secA;
                float average_6 = assi6/(float)student_secA;
                char av1[100];
                char av2[100];
                char av3[100];
                char av4[100];
                char av5[100];
                char av6[100];            


                sprintf(av1, "%f", average_1);
                sprintf(av2, "%f", average_2);
                sprintf(av3, "%f", average_3);
                sprintf(av4, "%f", average_4);
                sprintf(av5, "%f", average_5);
                sprintf(av6, "%f", average_6);

                sz2 = write(fd2, av1, strlen(av1));
                
                sz2 = write(fd2, "\n", strlen("\n"));
                sz2 = write(fd2, av2, strlen(av2));
                
                sz2 = write(fd2, "\n", strlen("\n"));
                sz2 = write(fd2, av3, strlen(av3));
                
                sz2 = write(fd2, "\n", strlen("\n"));
                sz2 = write(fd2, av4, strlen(av4));
                
                sz2 = write(fd2, "\n", strlen("\n"));
                sz2 = write(fd2, av5, strlen(av5));
                
                sz2 = write(fd2, "\n", strlen("\n"));
                sz2 = write(fd2, av6, strlen(av6));
               
                sz2 = write(fd2, "\n", strlen("\n"));

                char a[] = "\nSection B: \n";
            
                write(STDOUT_FILENO,a, sizeof(a));

                char aa[] = "\nAssignment 1: ";
            
                write(STDOUT_FILENO,aa, sizeof(aa)); 


                write(1, av1, strlen(av1));
                write(1, "\n", strlen("\n"));

                char aaa[] = "\nAssignment 2: ";
            
                write(STDOUT_FILENO,aaa, sizeof(aaa));

                write(1, av2, strlen(av2));
                write(1, "\n", strlen("\n"));

                char aaaa[] = "\nAssignment 3: ";
            
                write(STDOUT_FILENO,aaaa, sizeof(aaaa));


                write(1, av3, strlen(av3));
                write(1, "\n", strlen("\n"));

                char a2[] = "\nAssignment 4: ";
            
                write(STDOUT_FILENO,a2, sizeof(a2));


                write(1, av4, strlen(av4));
                write(1, "\n", strlen("\n"));

                char a1[] = "\nAssignment 5: ";
            
                write(STDOUT_FILENO,a1, sizeof(a1));


                write(1, av5, strlen(av5));
                write(1, "\n", strlen("\n"));

                char a3[] = "\nAssignment 6: ";
            
                write(STDOUT_FILENO,a3, sizeof(a3));

                write(1, av6, strlen(av6));
                write(1, "\n", strlen("\n"));



                pid_t cpid= waitpid(pid, &status, 0);
    }
}