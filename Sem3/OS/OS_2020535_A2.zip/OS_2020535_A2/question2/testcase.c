#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>

#define SYS_kernel_2d_memcpy 448

int main(){
    
    int row=3, column=3;

    float source[row][column];
    
    source[0][0] = 1.23;
    source[0][1] = 2.34;
    source[0][2] = 3.45;
    source[1][0] = 4.56;
    source[1][1] = 5.67;
    source[1][2] = 6.89;
    source[2][0] = 7.10;
    source[2][1] = 8.11;
    source[2][2] = 9.12;


    for(int i=0; i<row; i++){
        for(int j=0; j<column; j++){
            printf("%f ", source[i][j]);
        }
        printf("\n");
    }
    
    float destination[row][column];


    int res = syscall(448, destination, source, row, column);
    if(res==-1){
        printf("Error: System call failed\n");
    }
  
    else{
        printf("copied matrix:\n");
        for(int i=0; i<row; i++){
            for(int j=0; j<column; j++){
                printf("%f ", destination[i][j]);
            }
        printf("\n");
        }
    }    
    return res;
}

