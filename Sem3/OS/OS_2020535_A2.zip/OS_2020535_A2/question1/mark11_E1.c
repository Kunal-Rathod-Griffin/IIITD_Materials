#define _GNU_SOURCE
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/time.h>
#include <assert.h>
#include <stdint.h>


static int count = 0;
static int pid_s1;
void timer_handler (int signum)
{
 // printf ("timer expired %d times\n", ++count);
}

int rdrand16_step (uint16_t *rand)
{
    unsigned char ok;
    asm volatile ("rdrand %0; setc %1" : "=r" (*rand), "=qm" (ok));
    return (int)ok;
}
 
int main (int argc, char *argv[])
{

    pid_s1 = atoi(argv[1]);
    struct sigaction sa;
    struct itimerval timer;
 /* Install timer_handler as the signal handler for SIGVTALRM. */
    memset (&sa, 0, sizeof (sa));
    sa.sa_handler = &timer_handler;
    sigaction (SIGALRM, &sa, NULL);

 /* Configure the timer to expire after 250 msec... */
    timer.it_value.tv_sec = 1;
    timer.it_value.tv_usec = 0;
 /* ... and every 250 msec after that. */
    timer.it_interval.tv_sec = 1;
    timer.it_interval.tv_usec = 0;
 /* Start a virtual timer. It counts down whenever this process is
   executing. */

    setitimer (ITIMER_REAL, &timer, NULL);

    while (1){
      sleep(1);
        union sigval value;
    // value.sival_int = 100;
        char test[] = "A";


         uint16_t aaa = 0;
         rdrand16_step(&aaa);
         value.sival_int = aaa;
    // printf("it in E1: %d\n", value.sival_int);

        sigqueue(pid_s1, SIGTERM, value );
        kill(pid_s1, SIGTERM);

   }
}