
#define _GNU_SOURCE
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <sys/wait.h>
#include <sys/types.h>

void sig_handler_child(int signumber,siginfo_t* info,void* nonused)
{
    printf("\nChild S1: received a signal from parent\n");



    printf("\nthis is the random number: %d\n", (info->si_value.sival_int));
    // printf("address of  Additional data2: %d\n", (info->si_value.sival_ptr));
    sleep(1);
    // kill(getppid(), SIGUSR1);
}

int main(){
    pid_t pid;

    if((pid= fork())< 0 )
    {
        printf("Fork Failed\n");
        exit(1);
    }

    else if(pid == 0)
    {
    //     signal(SIGTERM, sig_handler_child);

        int k = pid; 
        // printf("pid in exec_tt %d\n", k);
        
        struct sigaction sa;

        sa.sa_sigaction = sig_handler_child; 
        sa.sa_flags = SA_SIGINFO; 
        sigemptyset(&sa.sa_mask);
        sigaction(SIGTERM, &sa, NULL);

        printf("Child S1: waiting for signal\n");
        pause();
    }

    else{

        sleep(1);
 
        printf("Parent: sending signal to Child\n");

        int k = pid; 
        // printf("pid in exec_tt %d\n", k);
    
        pid_t pid2;
        pid2 = fork();

        if(pid2 < 0)
        {
            printf("Fork failed for pid2\n");
            exit(1);
        }

        else if(pid2 == 0)
        {
            char buffer[100];

            sprintf(buffer, "%d", k);
            char *args[] = {"./mark11_E1", buffer , NULL};
            execvp("./mark11_E1", args);
        }

        else{
            
            sleep(5);
            char buffer2[100];
            sprintf(buffer2,  "%d", k);
            char *args[] = {"./mark11_E2", buffer2 , NULL};
            execvp("./mark11_E2", args);

        }
        

    }

    return 0;
}