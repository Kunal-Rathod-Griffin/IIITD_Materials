import java.util.ArrayList;
import java.util.Scanner;

class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<General> list = new ArrayList<>();

        TheMatrix zion = new TheMatrix(list);

        boolean done = false;
        String menu = "1. Add Matrix\n" +
                "2. Create matrices of requested matrix-types and label them with appropriate matrix-types.\n" +
                "3. Change the elements of a matrix as long as the fixed matrix-type labels remain valid.\n" +
                "4. Display all the matrix-type labels of a requested matrix. \n" +
                "5. Perform addition, subtraction, multiplication & division.\n" +
                "6. Perform element-wise operations.\n" +
                "7. Transpose matrices.\n" +
                "8. Inverse matrices.\n" +
                "9. Compute means: row-wise mean, column-wise mean, mean of all the elements.\n" +
                "10. Compute determinants.\n" +
                "11. Use singleton matrices as scalars, if requested.\n" +
                "12. Compute A+AT\n" +
                "for a matrix A.\n" +
                "13. Compute Eigen vectors and values.\n" +
                "14. Solve sets of linear equations using matrices.\n" +
                "15. Retrieve all the existing matrices (entered or created) having requested matrix-type labels\n" +
                "16. exit\n";
        System.out.println(menu);
        while(!done)
        {
            System.out.println();
            System.out.println("========================================");
            System.out.println("{menu}");
            System.out.print("Enter the id of the task: ");
            int k = sc.nextInt();
            if(k == 16)
            {
                System.out.println("Thank you.");
                done = true;
                break;
            }
            if(k == 1){
                System.out.println("Enter the number of Rows and Columns: ");
                System.out.print("Rows: ");
                int rows = sc.nextInt();
                System.out.print("Columns: ");
                int columns = sc.nextInt();

                ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();
//                int mat[][] = new int[rows][columns];
                for(int i =0; i< rows; i++)
                {
                    ArrayList<Integer> temp = new ArrayList<>();
                    mat.add(i, temp);
                }
                System.out.println("Enter the elements of the matrix");

                for(int i = 0; i< rows; i++)
                {
                    for(int j =0; j < columns; j++)
                    {

//                        mat[i][j] = sc.nextInt();
                        int x = sc.nextInt();
                        mat.get(i).add(j, x);

                    }
                }

                System.out.println("The matrix is: ");
                for(int i=0; i<rows; i++)
                {
                    for(int j =0; j < columns; j++)
                    {
                        System.out.print(mat.get(i).get(j) + " ");

                    }
                    System.out.println();
                }

                /////////////////////////////////
                zion.the_matrix_checker(mat);

//                General jj =  zion.list.get(0);
                System.out.print("ID given to this matrix is : " );
//                System.out.println(jj.final_type);
                System.out.println(zion.unique_id);

            }
            else if(k == 2){

                String matrices = "1. Rectangular Matrix\n" +
                        "2. Row Matrix\n" +
                        "3. Column Matrix\n" +
                        "4. Square Matrix\n" +
                        "5. Symmetric Matrix\n" +
                        "6. Skew-symmetric Matrix\n" +
                        "7. Upper-triangular Matrix\n" +
                        "8. Lower-triangular Matrix\n" +
                        "9. Singular Matrix\n" +
                        "10. Diagonal Matrix\n" +
                        "11. Scalar Matrix\n" +
                        "12. Identity Matrix\n" +
                        "13. Singleton Matrix\n" +
                        "14. Ones Matrix\n" +
                        "15. Null Matrix\n";

                System.out.println(matrices);
                System.out.print("Select the matrix: ");
                int type_matrix = sc.nextInt();

                if(type_matrix == 1)

                {
                        System.out.println("Enter rows and columns: ");
                        int rowR = sc.nextInt();
                        int colR = sc.nextInt();

                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int temp = 1;
                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
//                                int x = sc.nextInt();
                                mat.get(i).add(j, temp);
                                temp++;

                            }
                        }

                        zion.the_matrix_checker(mat);

                }
                else if(type_matrix == 2) {

                    System.out.println("Enter columns: ");
                    int rowR = 1;
                    int colR = sc.nextInt();

                    ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                    for (int i = 0; i < rowR; i++) {
                        ArrayList<Integer> temp = new ArrayList<>();
                        mat.add(i, temp);
                    }

                    int temp = 1;
                    for (int i = 0; i < rowR; i++) {
                        for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
//                            int x = sc.nextInt();
                            mat.get(i).add(j, temp);
                            temp++;

                        }
                    }

                    zion.the_matrix_checker(mat);

                }
                else if(type_matrix == 3)
                {
                    System.out.println("Enter rows: ");
                    int rowR = sc.nextInt();
                    int colR = 1;

                    ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                    for (int i = 0; i < rowR; i++) {
                        ArrayList<Integer> temp = new ArrayList<>();
                        mat.add(i, temp);
                    }

                    int temp = 1;
                    for (int i = 0; i < rowR; i++) {
                        for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
//                            int x = sc.nextInt();
                            mat.get(i).add(j, temp);
                            temp++;

                        }
                    }

                    zion.the_matrix_checker(mat);

                }
                else if(type_matrix == 4)
                {
                    System.out.println("Enter the dimentions of the Square matrix: ");

                    int colR = sc.nextInt();
                    int rowR = colR;

                    ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                    for (int i = 0; i < rowR; i++) {
                        ArrayList<Integer> temp = new ArrayList<>();
                        mat.add(i, temp);
                    }

                    int temp = 1;
                    for (int i = 0; i < rowR; i++) {
                        for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
//                            int x = sc.nextInt();
                            mat.get(i).add(j, temp);
                            temp++;

                        }
                    }

                    zion.the_matrix_checker(mat);

                }
                else if(type_matrix == 5)
                {
                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 1);
                        a1.add(1, 2);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 2);
                        a2.add(1,1);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i == j){
                                    mat.get(i).add(j,1 );
                                }
                                else if(i != j)
                                {
                                    mat.get(i).add(j,2 );
                                }


                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }

                }
                else if(type_matrix == 6)
                {
                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 0);
                        a1.add(1, 2);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, -2);
                        a2.add(1,0);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i == j){
                                    mat.get(i).add(j,0 );
                                }
                                else if(i < j)
                                {
                                    mat.get(i).add(j,2 );
                                }
                                else if(i > j)
                                {
                                    mat.get(i).add(j, -2);
                                }


                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }

                }
                else if(type_matrix == 7)
                {
                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 1);
                        a1.add(1, 1);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 0);
                        a2.add(1,1);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        int temp = 1;
                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i > j){
                                    mat.get(i).add(j,0 );
                                }
                                else{
                                    mat.get(i).add(j, temp);
                                    temp ++ ;
                                }


                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }


                }
                else if(type_matrix == 8){
                    //Lower
                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 1);
                        a1.add(1, 1);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 0);
                        a2.add(1,1);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        int temp = 1;
                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i < j){
                                    mat.get(i).add(j,0 );
                                }
                                else{
                                    mat.get(i).add(j, temp);
                                    temp ++ ;
                                }


                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }
                }
                else if(type_matrix == 9)
                {
                    System.out.println("Enter the dimentions: ");
                    int dim = sc.nextInt();

                    if(dim == 2)
                    {
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 2);
                        a1.add(1, 1);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 6);
                        a2.add(1,3);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }

                    else if (dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        mat.get(0).add(0, 2 ); mat.get(0).add(1, 0 ); mat.get(0).add(2, 0 );
                        mat.get(1).add(0, 0 ); mat.get(1).add(1, 2 ); mat.get(1).add(2, 6 );
                        mat.get(2).add(0, 0 ); mat.get(2).add(1, 1 ); mat.get(2).add(2, 3 );


                    }
                    else{

                    }
                }
                else if(type_matrix == 10)
                {
                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 2);
                        a1.add(1, 0);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 0);
                        a2.add(1,3);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        int temp = 1;
                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i == j)
                                {
                                    mat.get(i).add(j, temp);
                                    temp++;
                                }



                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }
                }
                else if(type_matrix == 11)
                {
                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 2);
                        a1.add(1, 0);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 0);
                        a2.add(1,2);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        int temp = 1;
                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i == j)
                                {
                                    mat.get(i).add(j, 2);

                                }



                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }
                }
                else if(type_matrix == 12) {

                    System.out.println("Enter the dimentions of the matrix: ");
                    int dim = sc.nextInt();
                    if(dim == 2){
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 1);
                        a1.add(1, 0);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 0);
                        a2.add(1,1);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }
                    else if(dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        int aa = 1;
                        int bb = 2;

                        int temp = 1;
                        for (int i = 0; i < rowR; i++) {
                            for (int j = 0; j < colR; j++) {

//                        mat[i][j] = sc.nextInt();
                                if(i == j)
                                {
                                    mat.get(i).add(j, 1);

                                }



                            }
                        }

                        zion.the_matrix_checker(mat);
                    }
                    else{

                    }

                }
                else if(type_matrix == 13)
                {
                    System.out.println("Enter element: ");
                    int n = sc.nextInt();

                    ArrayList<ArrayList<Integer>> mat = new ArrayList<>();
                    ArrayList<Integer> kkk = new ArrayList<>();
                    kkk.add(n);
                    mat.add(kkk);

                    zion.the_matrix_checker(mat);
                }
                else if(type_matrix == 14)
                {
                    System.out.println("Enter the dimentions: ");
                    int dim = sc.nextInt();

                    if(dim == 2)
                    {
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 1);
                        a1.add(1, 1);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 1);
                        a2.add(1,1);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }

                    else if (dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        mat.get(0).add(0, 1 ); mat.get(0).add(1, 1 ); mat.get(0).add(2, 1 );
                        mat.get(1).add(0, 1 ); mat.get(1).add(1, 1 ); mat.get(1).add(2, 1 );
                        mat.get(2).add(0, 1 ); mat.get(2).add(1, 1 ); mat.get(2).add(2, 1 );


                    }
                    else{

                    }
                }
                else if(type_matrix == 15)
                {
                    System.out.println("Enter the dimentions: ");
                    int dim = sc.nextInt();

                    if(dim == 2)
                    {
                        ArrayList<Integer> a1 = new ArrayList<>();
                        a1.add(0, 0);
                        a1.add(1, 0);

                        ArrayList<Integer> a2 = new ArrayList<>();
                        a2.add(0, 0);
                        a2.add(1,0);

                        ArrayList<ArrayList<Integer>> a3 = new ArrayList<>();
                        a3.add(0, a1);
                        a3.add(1, a2);


                        zion.the_matrix_checker(a3);
                    }

                    else if (dim == 3)
                    {
                        int rowR = 3;
                        int colR = 3;
                        ArrayList<ArrayList<Integer>> mat = new ArrayList<ArrayList<Integer>>();

                        for (int i = 0; i < rowR; i++) {
                            ArrayList<Integer> temp = new ArrayList<>();
                            mat.add(i, temp);
                        }

                        mat.get(0).add(0, 0 ); mat.get(0).add(1, 0 ); mat.get(0).add(2, 0 );
                        mat.get(1).add(0, 0 ); mat.get(1).add(1, 0 ); mat.get(1).add(2, 0 );
                        mat.get(2).add(0, 0 ); mat.get(2).add(1, 0 ); mat.get(2).add(2, 0 );


                    }
                    else{

                    }
                }

            }

            else if(k == 3)
            {
                System.out.println("Enter the id of the matrix: ");
                int id_mat = sc.nextInt();
                id_mat--;
                General obiwan = zion.list.get(id_mat);

                ArrayList<ArrayList<Integer>> mat = obiwan.m1.neo;

                System.out.println("Enter the row and column of that element: ");
                System.out.print("row number: ");
                int row = sc.nextInt();
                System.out.print("column number: ");
                int col =sc.nextInt();

                System.out.println("Enter the new value of the selected element: " );
                int val = sc.nextInt();

                mat.get(row).add(col, val);

                for(int i =0; i< mat.size(); i++)
                {

                    for(int j =0; j< mat.get(0).size(); j++)
                    {
                        System.out.print(mat.get(i).get(j) + " ");
                    }
                    System.out.println();

                }

                obiwan.m1.neo = mat;
                zion.list.add(id_mat, obiwan);

            }
            else if(k == 4){

                System.out.print("Enter the ID of the matrix: ");
                int id = sc.nextInt();
                id--;

                General obiwan = zion.list.get(id);

                ArrayList<String > labels = obiwan.labels;
//                System.out.println(obiwan.final_type);

                System.out.println("size: ---------" + labels.size());
                for(int i =0; i< labels.size(); i++)
                {
                    System.out.println(labels.get(i));
                }

            }
            else if(k == 7)
            {
                System.out.println("Enter the ID of the matrix: ");
                int id = sc.nextInt();
                id--;

                General kk = zion.list.get(id);

                int id_of_matrix = kk.matrix_id;
                System.out.println("id of matrix: " + id_of_matrix);


                if((id_of_matrix == 5) || (id_of_matrix == 10) || (id_of_matrix == 11) || (id_of_matrix == 12) || (id_of_matrix == 14) || (id_of_matrix == 15) ){
                    //5,10,11,12,14,15
                    //4,6,7,8,9
                    Square kk2 = (Square) kk;

                    kk2.Transpose(kk2.m1.neo);


                }
                else{

                    kk.transpose(kk.m1.neo);


                }
            }

            else if(k == 12){

                System.out.println("Enter the ID of the matrix: ");
                int id = sc.nextInt();
                id--;

                General kk = zion.list.get(id);

                int id_of_matrix = kk.matrix_id;

                Square kk2 = (Square) kk;

                ArrayList<ArrayList<Integer>> needed = kk.m1.neo;

                kk2.Transpose_sum(needed);


            }
            else if(k == 10){

                System.out.println("Enter the ID of the matrix: ");
                int id = sc.nextInt();
                id--;

                General kk = zion.list.get(id);

                int id_of_matrix = kk.matrix_id;

                Square kk2 = (Square) kk;

                ArrayList<ArrayList<Integer>> needed = kk.m1.neo;

                kk2.Determinants(needed);
            }

            else if(k == 9){

                System.out.println("Enter the ID of the matrix: ");
                int id = sc.nextInt();
                id--;

                General kk = zion.list.get(id);
                ArrayList<ArrayList<Integer>> needed = kk.m1.neo;
                int id_of_matrix = kk.matrix_id;

                System.out.println("0. Row-wise mean\n" +
                        "1. Column-wise mean");

                int choice = sc.nextInt();

                if(choice == 0){

                    kk.Row_mean(needed);
                }
                else if(choice == 1)
                {
                    kk.Column_mean(needed);
                }
            }

            else if(k == 5)
            {
                System.out.print("Enter the id of the first matrix: ");
                int n = sc.nextInt();
                n--;
                System.out.print("Enter the id of second matrix: ");
                int m = sc.nextInt();
                m--;
                System.out.println("1. addition\n" +
                        "2. subtraction\n" +
                        "3. multiplication\n" +
                        "4. division\n");

                int selected_choise = sc.nextInt();
                General obiwan = zion.list.get(n);
                General obwan2 = zion.list.get(m);
                if(selected_choise == 1) {


                    obiwan.add_matrix(obwan2.m1.neo);
                }
                else if(selected_choise == 2)
                {
                    obiwan.sub_matrix(obwan2.m1.neo);
                }
                else if(selected_choise == 3)
                {
                    obiwan.mul_matrix(obwan2.m1.neo);
                }
                else if(selected_choise == 4)
                {
                    String type1 = obiwan.final_type;
                    String type2 = obwan2.final_type;

                    if(type1.equals("Singular") || type2.equals("Singular")){
                        System.out.println("can't divide singular");
                    }
                    else {
                        ArrayList<ArrayList<Integer>> temp = obiwan.m1.neo;
                        if (temp.size() != temp.get(0).size()) {
                            System.out.println("cant divide this matrix. it's not a square");
                        } else {
                            Square obiwan3 = (Square) obiwan;
                            obiwan3.Division(obwan2.m1.neo);
                        }
                    }
                }
                else{

                }
            }

            else if(k == 8)
            {
                System.out.println("Enter the ID of the matrix: ");
                int id = sc.nextInt();
                id--;

                General kk = zion.list.get(id);

                int id_of_matrix = kk.matrix_id;

                Square kk2 = (Square) kk;

                kk2.Inverse(kk.m1.neo);

            }
            else if(k == 6)
            {
                System.out.println("Enter the ID of the matrices: ");
                int id = sc.nextInt();
                int id2 = sc.nextInt();

                id--;
                id2--;

                General kk = zion.list.get(id);
                General rr = zion.list.get(id2);

                int id_of_matrix = kk.matrix_id;
                System.out.println("Enter the id of operation: \n" +
                        "1. additoin\n" +
                        "2. substraction\n" +
                        "3. multiplication\n" +
                        "4. division\n");

                int operation_id = sc.nextInt();
                kk.element_wise(rr.m1.neo, operation_id);

            }
            else if(k == 11)
            {
                System.out.println("select the singleton matrix only: ");
                int id = sc.nextInt();
                id--;

                General obiwan = zion.list.get(id);

                System.out.println("select the operation: " +
                        "1. multiplication" +
                        "2. addition");

                int operation_id = sc.nextInt();

                System.out.println("Select another matrix for this operation: ");
                int mat_id = sc.nextInt();

                mat_id--;

                General mat = zion.list.get(mat_id);

                mat.scalar(obiwan.m1.neo, operation_id);

            }

            else if(k == 13){

                System.out.println("select the  matrix : ");
                int id = sc.nextInt();
                id--;

                General obiwan = zion.list.get(id);

                ArrayList<ArrayList<Integer>> mat = obiwan.m1.neo;

                int rows = mat.size();

                if(rows == 1){
                    System.out.println(mat.get(0).get(0));
                }
                else if (rows == 2){
                    Square obi2 = (Square) obiwan;

                    System.out.println("determinant: ");
                    int v = obi2.Determinants(obi2.m1.neo);

                    int tt = 0;
                    for(int i =0; i<rows; i++)
                    {
                        tt+= mat.get(i).get(i);
                    }

                    int aa = (tt*tt) - (4*v);
                    float bb = (float) Math.sqrt(aa);

                    float a1 = (float) (tt + bb) / 2;
                    float a2 = (float) (tt - bb) /2;

                    System.out.println(a1);
                    System.out.println(a2);

                }


            }

            else if(k == 14){
                System.out.println("select A matrix: ");
                int a1 = sc.nextInt();
                a1--;

                System.out.println("select B matrix: ");
                int b = sc.nextInt();
                b--;

                General A = zion.list.get(a1);
                General B = zion.list.get(b);

                Square A1 = (Square) A;

                ArrayList<ArrayList<Float>> inverse_A = A1.Inverse(A1.m1.neo);
                ArrayList<ArrayList<Integer>> mat_b = B.m1.neo;
                float a = inverse_A.get(0).get(0) * mat_b.get(0).get(0) + inverse_A.get(0).get(1) * mat_b.get(0).get(1);
                float a2 = inverse_A.get(1).get(0) * mat_b.get(0).get(0) + inverse_A.get(1).get(1) * mat_b.get(0).get(1);
                System.out.println(a);
                System.out.println(a2);

            }

            else if(k == 15)
            {

                String matrices = "1. Rectangular Matrix\n" +
                        "2. Row Matrix\n" +
                        "3. Column Matrix\n" +
                        "4. Square Matrix\n" +
                        "5. Symmetric Matrix\n" +
                        "6. Skew-symmetric Matrix\n" +
                        "7. Upper-triangular Matrix\n" +
                        "8. Lower-triangular Matrix\n" +
                        "9. Singular Matrix\n" +
                        "10. Diagonal Matrix\n" +
                        "11. Scalar Matrix\n" +
                        "12. Identity Matrix\n" +
                        "13. Singleton Matrix\n" +
                        "14. Ones Matrix\n" +
                        "15. Null Matrix\n";

                System.out.println(matrices);
                System.out.println("Select the matrix type: ");
                int kk = sc.nextInt();
                kk--;

                for(int i =0; i< zion.list.size(); i++)
                {
                    General obj = zion.list.get(i);
                    ArrayList<ArrayList<Integer>> mat = obj.m1.neo;

                    for(int j =0; j<obj.labels.size(); j++)
                    {
                        ArrayList<String> labels = obj.labels;
                        if(kk == 1){
                            if(labels.get(j).equals("Rectangle")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 2)
                        {
                            if(labels.get(j).equals("Row")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 3)
                        {
                            if(labels.get(j).equals("Column")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 4)
                        {
                            if(labels.get(j).equals("Square")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 5)
                        {
                            if(labels.get(j).equals("Symmetric")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 6)
                        {
                            if(labels.get(j).equals("Skew")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 7)
                        {
                            if(labels.get(j).equals("Upper")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 8)
                        {
                            if(labels.get(j).equals("Lower")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        if(kk == 9)
                        {
                            if(labels.get(j).equals("Singular")){
                            System.out.println(obj.matrix_id);
                        }
                        }
                        if(kk == 10)
                        {
                            if(labels.get(j).equals("Diagonal")){
                            System.out.println(obj.matrix_id);
                        }
                        }
                        if(kk == 11)
                        {
                        if(labels.get(j).equals("Scalar")){
                            System.out.println(obj.matrix_id);
                        }
                        }
                        if(kk == 12)
                        {
                            if(labels.get(j).equals("Identity")){
                                System.out.println(obj.matrix_id);
                            }
                        }if(kk == 13)
                        {
                        if(labels.get(j).equals("Singleton")){
                            System.out.println(obj.matrix_id);
                        }
                        }
                        if(kk == 14)
                        {
                        if(labels.get(j).equals("Ones")){
                            System.out.println(obj.matrix_id);
                        }
                        }
                        if(kk == 15)
                        {
                            if(labels.get(j).equals("Null")){
                                System.out.println(obj.matrix_id);
                            }
                        }
                        else{


                        }




                    }
                }

            }

        }

    }

}

class matrix{

    ArrayList<ArrayList<Integer>> neo;
    int id;
    ArrayList<String> labels;

    matrix(){
        labels = new ArrayList<>();
    }

}

class TheMatrix{

    ArrayList<General> list;
    int unique_id;

    TheMatrix( ArrayList<General> list )
    {
        this.list = list;
        this.unique_id = 0;
    }

    public void the_matrix_checker(ArrayList<ArrayList<Integer>> mat)
    {
//        matrix new_mat = new matrix();
//
//        Square final_type = new Square();
//
//        final_type.m1 = new_mat;
//
//        list.add(final_type);

        int column = mat.get(0).size();
        int row = mat.size();

        matrix new_matrix = new matrix();
        this.unique_id++;
        new_matrix.id = this.unique_id;

        if(row == column)
        {

            //Square Square Square
            if(row == 1)
            {
                Singleton new_type = new Singleton();
                new_type.matrix_id = 13;
                new_matrix.neo = mat;
                new_type.m1 = new_matrix;
                new_type.labels.add("Singleton");
                new_type.labels.add("Square");

                new_type.final_type = "Singleton";
                list.add(new_type);

            }

            else if(row == 2)
            {

                //00 01
                //10 11
                //a1 a2
                //a3 a4
                int a1 = mat.get(0).get(0);
                System.out.println("a1 "+ a1);
                int a2 = mat.get(0).get(1);
                System.out.println("a2 "+ a2);
                int a3 = mat.get(1).get(0);
                System.out.println("a3 "+ a3);
                int a4 = mat.get(1).get(1);
                System.out.println("a4 "+ a4);
                int value = a4*a1 - a2*a3;


//                int a1 = mat[1][1];
//                int a2 = mat[1][2];
//                int a3 = mat[2][1];
//                int a4 = mat[2][2];
                //11 12
                //21 22
//                int value = mat[1][2] * mat[2][2] - mat[1][2]* mat[2][1];

//                if(value == 0){
//
//                    Singular new_type = new Singular();
//                    new_matrix.neo = mat;
//
//                    new_type.m1 = new_matrix;
//
//                    new_type.final_type = "Singular";
//                    list.add(new_type);
//
//
//                }


                    if(a1 == 1 && a2 == 1 && a3 == 1 && a4 == 1){

                        Ones new_type = new Ones();
                        new_type.matrix_id = 14;

                        new_matrix.neo = mat;
                        new_type.labels.add(0, "Square");
                        new_type.labels.add(1, "Symmetric");
                        new_type.labels.add(2, "Ones");
                        new_type.m1 = new_matrix;

                        new_type.final_type = "Ones";

                        list.add(new_type);
                        return;
                    }
                    else if(a1 == 0 && a2 == 0 && a3 == 0 && a4 == 0){

                        Null new_type = new Null();
                        new_type.matrix_id = 15;
                        new_matrix.neo = mat;
                        new_type.labels.add(0, "Null");
                        new_type.labels.add(1, "Square");



                        new_type.m1 = new_matrix;

                        new_type.final_type = "Null";
                        list.add(new_type);
                        return;
                    }
                    else if(a1 != 0 && a2 != 0 && a3 == 0 && a4 != 0){

                        Upper new_type = new Upper();
                        new_type.matrix_id = 7;
//                        ArrayList<Integer> row1 = new ArrayList<>();
//                        row1.add(0, a1);
//                        row1.add(1, a2);
//
//                        ArrayList<Integer> row2 = new ArrayList<>();
//                        row2.add(0,a4 );
                        new_matrix.neo = mat;
                        new_type.labels.add(0, "Upper");
                        new_type.labels.add(1, "Square");

                        new_type.m1 = new_matrix;

                        new_type.final_type = "Upper";


                        list.add(new_type);
                        return;
                    }
                    else if(a1 != 0 && a2 == 0 && a3 != 0 && a4 != 0){

                        Lower new_type = new Lower();
                        new_type.matrix_id = 8;
//                        ArrayList<Integer> row1 = new ArrayList<>();
//                        row1.add(0, a1);
//                        row1.add(1, a2);
//
//                        ArrayList<Integer> row2 = new ArrayList<>();
//                        row2.add(0,a4 );
                        new_matrix.neo = mat;
                        new_type.labels.add(0, "Lower");
                        new_type.labels.add(1, "Square");


                        new_type.m1 = new_matrix;

                        new_type.final_type = "Lower";


                        list.add(new_type);
                        return;
                    }
                    else if(a2==0 && a3 == 0){

                        if(a1 != a4){
                            Diagonal new_type = new Diagonal();
                            new_type.matrix_id = 10;
                            ArrayList<Integer> kk = new ArrayList<>();
                            kk.add(0, a1);
                            kk.add(1, a4);

                            ArrayList<ArrayList<Integer>> rr = new ArrayList<>();
                            rr.add(0, kk);

                            new_matrix.neo = mat;
                            new_type.labels.add(0, "Diagonal");
                            new_type.labels.add(1, "Square");

                            new_type.labels.add(2, "Symmetric");
                            new_type.m1 = new_matrix;
                            new_type.final_type = "Diagonal";
                            list.add(new_type);
                            return;
                        }
                        else if((a1 == a4) && a1 != 1){
                            Scalar new_type = new Scalar();
                            new_type.matrix_id = 11;
                            ArrayList<Integer> kk = new ArrayList<>();
                            kk.add(0, a1);
                            kk.add(1, a4);

                            ArrayList<ArrayList<Integer>> rr = new ArrayList<>();
                            rr.add(0, kk);

                            new_matrix.neo = mat;
                            new_type.labels.add(0, "Scalar");
                            new_type.labels.add(1, "Square");
                            new_type.labels.add(2, "Symmetric");

                            new_type.labels.add(3, "Diagonal");
                            new_type.labels.add(4, "Singular");
                            new_type.m1 = new_matrix;
                            new_type.final_type = "Scalar";
                            list.add(new_type);
                            return;
                        }
                        else if((a1 == a4) && a1 == 1){
                            Identity new_type = new Identity();
                            new_type.matrix_id = 12;
                            ArrayList<Integer> kk = new ArrayList<>();
                            kk.add(0, a1);
                            kk.add(1, a4);

                            ArrayList<ArrayList<Integer>> rr = new ArrayList<>();
                            rr.add(0, kk);

                            new_matrix.neo = mat;
                            new_type.labels.add(0, "Identity");
                            new_type.labels.add(1, "Square");
                            new_type.labels.add(2, "Symmetric");

                            new_type.labels.add(3, "Diagonal");
                            new_type.labels.add(4, "Singular");
                            new_type.m1 = new_matrix;
                            new_type.final_type = "Identity";
                            list.add(new_type);
                            return;
                        }


                    }
                    else if(a2==a3){

                        Symmetric new_type = new Symmetric();
                        new_type.matrix_id = 5;
//
                        new_matrix.neo = mat;

                        new_type.labels.add(0, "Symmetric");
                        new_type.labels.add(1, "Square");
                        new_type.m1 = new_matrix;

                        new_type.final_type = "Symmetric";


                        list.add(new_type);
                        return;
                    }
                    else if(a2== -a3){

                        Skew new_type = new Skew();
                        new_type.matrix_id = 6;
                        new_matrix.neo = mat;
                        new_type.labels.add(0, "Skew");
                        new_type.labels.add(1, "Square");
                        new_type.m1 = new_matrix;

                        new_type.final_type = "Skew";
                        list.add(new_type);
                        return;
                    }
                    else if(value == 0){

                    Singular new_type = new Singular();
                    new_type.matrix_id = 9;
                    new_matrix.neo = mat;
                    new_type.labels.add(0, "Singular");
                    new_type.labels.add(1, "Square");
                    new_type.m1 = new_matrix;

                    new_type.final_type = "Singular";
                    list.add(new_type);
                    return;


                    }
                    else{
                        Square new_type = new Square();
                        new_type.matrix_id = 4;
                        new_matrix.neo = mat;

                        new_type.labels.add(0, "Square");
                        new_type.m1 = new_matrix;

                        new_type.final_type = "Square";
                        list.add(new_type);
                        return;

                    }



            }
            else if(row == 3)
            {

//                int column = mat.get(0).size();
//                int row = mat.size();
//
//                matrix new_matrix = new matrix();
//                new_matrix.id = unique_id;
                //a1 a2 a3
                //a4 a5 a6
                //a7 a8 a9

                int temp[]  = new int[9];
                int kk = 0;

                for(int i =0; i< row; i++)
                {
                    for(int j =0; j< column; j++)
                    {
                        int k = mat.get(i).get(j);
                        temp[kk] = k;
                        kk++;
                    }
                }

                //checking if the matrix is ONES ONES ONES
                boolean are_all_ones = true;
                boolean are_all_zeros = true;
                for(int i =0; i<9; i++)
                {
                    if(temp[i] != 1)
                    {
                        are_all_ones = false;
//                        break;
                    }

                    if(temp[i] != 0)
                    {
                        are_all_zeros = false;
                    }
                }

                if(are_all_ones == true)
                {
                    Ones new_type = new Ones();
                    new_type.matrix_id = 14;
                    new_matrix.neo = mat;
                    new_type.labels.add(0, "Ones");
                    new_type.labels.add(1, "Symmetric");
                    new_type.labels.add(2, "Square");
                    new_type.labels.add(3, "Singular");

                    new_type.m1 = new_matrix;
                    new_type.final_type = "Ones";

                    list.add(new_type);
                    return;

                }
                //checing for NULL NULL NULL
                else if(are_all_zeros == true)
                {
                    Null new_type = new Null();
                    new_type.matrix_id = 15;
                    new_matrix.neo = mat;

                    new_type.labels.add(0, "Null");
                    new_type.labels.add(1, "Symmetric");
                    new_type.labels.add(2, "Square");
                    new_type.labels.add(3, "Singular");
                    new_type.m1 = new_matrix;
                    new_type.final_type = "Null";

                    list.add(new_type);
                    return;
                }
                //checking for DIAGONAL DIAGONAL DIAGONAL

                boolean is_the_matrix_diagonal = true;

                for(int i =0; i< row; i++)
                {
                    for(int j =0; j< column ; j++)
                    {
                        if(i == j)
                        {
                            continue;
                        }
                        else{
                            int tempo = mat.get(i).get(j);

                            if(tempo != 0)
                            {
                                is_the_matrix_diagonal = false;
                                break;
                            }
                        }
                    }
                }
                //a1 a2 a3
                //a4 a5 a6
                //a7 a8 a9

                int a1 = mat.get(0).get(0);  int a2 = mat.get(0).get(1);  int a3 = mat.get(0).get(2);
                int a4 = mat.get(1).get(0);  int a5 = mat.get(1).get(1);  int a6 = mat.get(1).get(2);
                int a7 = mat.get(2).get(0);  int a8 = mat.get(2).get(1);  int a9 = mat.get(2).get(2);

                if(is_the_matrix_diagonal == true)
                {
                    if( (a1==a5) &&  (a5==a9) && (a1 != 1)  && (a1 != 0))
                    {
                        //SCALAR SCALAR SCALAR

                        ArrayList<Integer> diagonal = new ArrayList<>();

                        diagonal.add(0, a1);
                        diagonal.add(1, a5);
                        diagonal.add(2, a9);

                        ArrayList<ArrayList<Integer>> final_diagonal = new ArrayList<ArrayList<Integer>>();

                        final_diagonal.add(0, diagonal);

                        Scalar new_type = new Scalar();
                        new_type.matrix_id = 11;
                        new_matrix.neo = mat;

                        new_type.labels.add(0, "Scalar");
                        new_type.labels.add(1, "Symmetric");
                        new_type.labels.add(2, "Square");
                        new_type.labels.add(3, "Diagonal");


                        new_type.m1 = new_matrix;
                        new_type.final_type = "Scalar";

                        list.add(new_type);
                        return;
                    }
                    else if( (a1==a5) &&  (a5==a9) && (a1 == 1))
                    {
                        //IDENTITY IDENTITY IDENTITY

                        ArrayList<Integer> diagonal = new ArrayList<>();

                        diagonal.add(0, a1);
                        diagonal.add(1, a5);
                        diagonal.add(2, a9);

                        ArrayList<ArrayList<Integer>> final_diagonal = new ArrayList<ArrayList<Integer>>();

                        final_diagonal.add(0, diagonal);

                        Identity new_type = new Identity();
                        new_type.matrix_id = 12;
                        new_matrix.neo = mat;
                        new_type.labels.add(0, "Identity");
                        new_type.labels.add(1, "Symmetric");
                        new_type.labels.add(2, "Square");
                        new_type.labels.add(3, "Diagonal");
                        new_type.labels.add(4, "Singular");



                        new_type.m1 = new_matrix;
                        new_type.final_type = "Identity";

                        list.add(new_type);
                        return;
                    }
                    else if( (a1 != a5) || (a5 != a9) )
                    {
                        //DIAGONAL DIAGONAL DIAGONAL

                        ArrayList<Integer> diagonal = new ArrayList<>();

                        diagonal.add(0, a1);
                        diagonal.add(1, a5);
                        diagonal.add(2, a9);

                        ArrayList<ArrayList<Integer>> final_diagonal = new ArrayList<ArrayList<Integer>>();

                        final_diagonal.add(0, diagonal);

                        Diagonal new_type = new Diagonal();
                        new_type.matrix_id = 10;
                        new_matrix.neo = mat;

                        new_type.labels.add(0, "Diagonal");
                        new_type.labels.add(1, "Symmetric");
                        new_type.labels.add(2, "Square");

                        new_type.m1 = new_matrix;
                        new_type.final_type = "Diagonal";

                        list.add(new_type);
                        return;
                    }

                }

                if( (a2 == -a4) && (a3 == -a7 ) && (a6 == -a8) && (a1==a5) && (a5==a9) && (a1 == 0) )
                {
                    //SKEW SKEW SKEW
                    Skew new_type = new Skew();
                    new_type.matrix_id = 6;
                    new_matrix.neo = mat;

                    new_type.labels.add(0, "Skew");
                    new_type.labels.add(1, "Square");


                    new_type.m1 = new_matrix;
                    new_type.final_type = "Skew";

                    list.add(new_type);
                    return;
                }
                //UPPER UPPER UPPER
                //a1 a2 a3
                //a4 a5 a6
                //a7 a8 a9
//                int a1 = mat.get(0).get(0);  int a2 = mat.get(0).get(1);  int a3 = mat.get(0).get(2);
//                int a4 = mat.get(1).get(0);  int a5 = mat.get(1).get(1);  int a6 = mat.get(1).get(2);
//                int a7 = mat.get(2).get(0);  int a8 = mat.get(2).get(1);  int a9 = mat.get(2).get(2);

                if( (a4==a7) && (a7==a8) && (a4 == 0) ){
                    //UPPER UPPER UPPER

                    Upper new_type = new Upper();
                    new_type.matrix_id = 7;
                    new_matrix.neo = mat;
                    new_type.labels.add(0, "Upper");
                    new_type.labels.add(1, "Square");

                    new_type.m1 = new_matrix;
                    new_type.final_type = "Upper";

                    list.add(new_type);
                    return;

                }
                else if( (a2==a3) && (a3==a6) && (a2 == 0) ){

                    //LOWER LOWER LOWER
                    Lower new_type = new Lower();
                    new_type.matrix_id = 8;
                    new_matrix.neo = mat;
                    new_type.labels.add(0, "Lower");
                    new_type.labels.add(1, "Square");
                    new_type.m1 = new_matrix;
                    new_type.final_type = "Lower";

                    list.add(new_type);
                    return;
                }

                else if( (a2 == a4) && (a3 == a7 ) && (a6 == a8) )
                {
                    Symmetric new_type = new Symmetric();
                    new_type.matrix_id = 5;
                    new_matrix.neo = mat;
                    new_type.labels.add(0, "Symmetric");
                    new_type.labels.add(1, "Square");

                    new_type.m1 = new_matrix;
                    new_type.final_type = "Symmetric";

                    list.add(new_type);
                    return;

                }

                //a1 a2 a3
                //a4 a5 a6
                //a7 a8 a9

                int value = a1*(a5*a9 - a8*a6) - a2*(a4*a9 - a6*a7) + a3*(a4*a8 - a7*a5);

                if(value == 0){
                    //Singular Singular Singulsr
                    Singular new_type = new Singular();
                    new_type.matrix_id = 9;
                    new_matrix.neo = mat;

                    new_type.labels.add(0, "Singular");
                    new_type.labels.add(1, "Square");
                    new_type.m1 = new_matrix;
                    new_type.final_type = "Singular";

                    list.add(new_type);
                    return;

                }

                else{
                    //This is only Square
                    Square new_type = new Square();
                    new_type.matrix_id = 4;
                    new_matrix.neo = mat;

                    new_type.labels.add(0, "Square");
                    new_type.m1 = new_matrix;
                    new_type.final_type = "Square";

                    list.add(new_type);
                    return;

                }




            }


        }
        else{

            if(row == 1){
                //Row Row Row
                Row new_type = new Row();
                new_type.matrix_id = 2;
                new_matrix.neo = mat;
                new_type.labels.add(0, "Row");
                new_type.labels.add(1, "Rectangle");
                new_type.m1 = new_matrix;
                new_type.final_type = "Row";

                list.add(new_type);
                return;
            }
            else if(column == 1){

                Column new_type = new Column();
                new_type.matrix_id = 3;
                new_matrix.neo = mat;

                new_type.labels.add(0, "Column");
                new_type.labels.add(1, "Rectangle");
                new_type.m1 = new_matrix;
                new_type.final_type = "Column";

                list.add(new_type);
                return;
            }
            else{

                Rectangle new_type = new Rectangle();
                new_type.matrix_id = 1;
                new_matrix.neo = mat;

                new_type.labels.add(0, "Rectangle");
                new_type.m1 = new_matrix;
                new_type.final_type = "Rectangle";

                list.add(new_type);
                return;
            }


        }


    }

}

class General{

    matrix m1;
    String final_type;
    ArrayList<String > labels;
    int matrix_id;

    General()
    {
        labels = new ArrayList<>();
    }

    public void scalar(ArrayList<ArrayList<Integer>> scalar , int operation_id)
    {
        int number = scalar.get(0).get(0);

        ArrayList<ArrayList<Integer>> mat = m1.neo;

        int rows = mat.size();
        int col = mat.get(0).size();

        for(int i =0; i< rows;i++)
        {
            for(int j =0; j < col; j++)
            {
                if(operation_id == 1)
                {
                    System.out.print( (float) (number * mat.get(i).get(j) ) + " " );
                }
                else if(operation_id == 2)
                {
                    System.out.print( (float) mat.get(i).get(j) / number + " " );
                }
            }
            System.out.println();
        }

    }

    public void element_wise(ArrayList<ArrayList<Integer>> mat, int id_of_operation){
        ArrayList<ArrayList<Integer>> mat2 = m1.neo;

        int row1 = mat.size();
        int col1 = mat.get(0).size();

        int row2 = mat2.size();
        int col2 = mat2.get(0).size();
        //id_of_operation :
        //1 sum
        //2 sub
        //3 mul
        //4 division


        if( (row1 == row2) && (col1== col2))
        {
            for(int i =0; i< row1; i++)
            {
                for(int j =0; j < col1; j++)
                {
                    if(id_of_operation == 1)
                    {
                        System.out.print(mat.get(i).get(j) + mat2.get(i).get(j) + " ");
                    }
                    if(id_of_operation == 2)
                    {
                        System.out.print(mat.get(i).get(j) - mat2.get(i).get(j) + " ");
                    }
                    if(id_of_operation == 3)
                    {
                        System.out.print(mat.get(i).get(j) * mat2.get(i).get(j) + " ");
                    }
                    if(id_of_operation == 4)
                    {
                        System.out.print((float) mat.get(i).get(j) / (float) mat2.get(i).get(j) + " ");
                    }
                }
                System.out.println();
            }

        } else{
            System.out.println("can't do this operation for this two matrices");
        }
    }

    public void mul_matrix(ArrayList<ArrayList<Integer>> mat ){



        ArrayList<ArrayList<Integer>> mat2 = m1.neo;
//        //1 2 3  7 8
//        //4 5 6  10 11
//        //       12 13
        int row1 = mat.size(); //2
        int col1 = mat.get(0).size(); //3
//
        int row2 = mat2.size(); //3
        int col2 = mat2.get(0).size(); //2

        ArrayList<ArrayList<Integer>> ans = new ArrayList<>();

        for(int i =0; i< row1; i++)
        {
            ArrayList<Integer> temp = new ArrayList<>();

            ans.add(temp);
        }


        for(int i =0; i< row1; i++)
        {

            for(int j =0; j< col2; j++){
                int kk = 0;

                for(int ii =0; ii< row2; ii++)
                {
                    kk+= mat.get(i).get(ii) + mat2.get(ii).get(i);
                }

                ans.get(i).add(j, kk);
            }
        }

        for(int i =0; i< row1; i++)
        {
            for(int j =0; j< col2;j++)
            {
                System.out.print((float) ans.get(i).get(j) + " ");
            }
            System.out.println();
        }

    }

    public void sub_matrix(ArrayList<ArrayList<Integer>> mat ){

        ArrayList<ArrayList<Integer>> mat2 = m1.neo;

        int row1 = mat.size();
        int col1 = mat.get(0).size();

        int row2 = mat2.size();
        int col2 = mat2.get(0).size();

        if( (row1 == row2) || (col1 == col2) ){

            ArrayList<ArrayList<Integer>> ans  = new ArrayList<>();

            for(int i =0; i< row1; i++)
            {
                ArrayList<Integer> temp = new ArrayList<>();

                ans.add(temp);
            }

            for(int i =0; i< row1; i++)
            {
                for(int j =0; j<row2; j++)
                {
                    int k = mat.get(i).get(j) - mat2.get(i).get(j);
                    ans.get(i).add(j, k);
                }
            }

            for(int i =0; i< row1; i++)
            {
                for(int j =0; j<col1; j++)
                {
                    System.out.print((float) ans.get(i).get(j) + " ");
                }
                System.out.println();
            }
        }
        else{
            System.out.println("you can not sub this two matrix.");
        }

    }

    public void add_matrix(ArrayList<ArrayList<Integer>> mat ){

        ArrayList<ArrayList<Integer>> mat2 = m1.neo;

        int row1 = mat.size();
        int col1 = mat.get(0).size();

        int row2 = mat2.size();
        int col2 = mat2.get(0).size();

        if( (row1 == row2) || (col1 == col2) ){

            ArrayList<ArrayList<Integer>> ans  = new ArrayList<>();

            for(int i =0; i< row1; i++)
            {
                ArrayList<Integer> temp = new ArrayList<>();

                ans.add(temp);
            }

            for(int i =0; i< row1; i++)
            {
                for(int j =0; j<row2; j++)
                {
                    int k = mat.get(i).get(j) + mat2.get(i).get(j);
                    ans.get(i).add(j, k);
                }
            }

            for(int i =0; i< row1; i++)
            {
                for(int j =0; j<col1; j++)
                {
                    System.out.print((float) ans.get(i).get(j) + " ");
                }
                System.out.println();
            }
        }
        else{
            System.out.println("you can not add this two matrix.");
        }

    }

    public void Row_mean(ArrayList<ArrayList<Integer>> mat)
    {

        int rows = mat.size();
        int columns = mat.get(0).size();

        for(int i =0; i< rows; i++)
        {
            int row_sum = 0;
            for(int j = 0; j< columns; j++)
            {
                int k = mat.get(i).get(j);
                row_sum += k;
            }
            float total = (float) row_sum/ (float) columns;
            System.out.println(total);

        }

    }

    public void Column_mean(ArrayList<ArrayList<Integer>> mat){

        int rows = mat.size();
        int columns = mat.get(0).size();

        for(int j = 0; j<columns; j++)
        {
            int column_sum = 0;
            for(int i =0; i<rows; i++)
            {
                int k = mat.get(i).get(j);
                column_sum += k;
            }

            float total_sum = (float)  column_sum / (float) rows;
            System.out.print(total_sum + " ");
        }

        System.out.println();

    }


    public ArrayList<ArrayList<Integer>> transpose(ArrayList<ArrayList<Integer>> matrix ){

        ArrayList<ArrayList<Integer>> ans = new ArrayList<>();

        int rows = matrix.size();
        int columns = matrix.get(0).size();

        for(int i =0; i< columns; i++)
        {
            ArrayList<Integer> temp = new ArrayList<>();
            ans.add(i, temp);

        }

        for(int i =0; i< columns; i++){
//            int jj = 0;

            for(int j =0; j < rows; j++){

                int k =  matrix.get(j).get(i);
                ans.get(i).add(j, k);

            }
            System.out.println();
        }

        for(int i =0; i< ans.size(); i++)
        {

            for(int j =0; j<ans.get(0).size() ; j++){
                System.out.print(ans.get(i).get(j) + " ");
            }
            System.out.println();
        }

        return  ans;
    }


}

class Square extends General{

//    matrix m1;

    public void Division( ArrayList<ArrayList<Integer>> mat)
    {

        ArrayList<ArrayList<Integer>> mat1 = m1.neo;


        int row2 = mat.size();
        int col2 = mat.get(0).size();
        int row1 = mat1.size();
        int col1 = mat1.get(0).size();


        if(row2 != col2)
        {
            System.out.println("can't divide. both matrix has to be sqaure matrix");
        }

        else{
            ArrayList<ArrayList<Float>> inverse = Inverse(mat);

            for(int i =0; i< row1; i++)
            {

                for(int j =0; j< col2; j++){
                    int kk = 0;

                    for(int ii =0; ii< row2; ii++)
                    {
                        kk+= mat1.get(i).get(ii) + mat.get(ii).get(i);
                    }

                    System.out.print((float) kk + " ");
                }
                System.out.println();
            }


            }


    }


    public int Determinants(ArrayList<ArrayList<Integer>> matrix){

        int values = 0;
        int size = matrix.size();

        if(size == 2)
        {
            //a1 a2
            //a3 a4
            int a1 = matrix.get(0).get(0); int a2 = matrix.get(0).get(1);
            int a3 = matrix.get(1).get(0); int a4 = matrix.get(1).get(1);
             values = a1*a4 - a2*a3;
            System.out.println((float) values);
            return values;
        }

        else if(size == 3){

            //a1 a2 a3
            //a4 a5 a6
            //a7 a8 a9

            int a1 = matrix.get(0).get(0); int a2 = matrix.get(0).get(1); int a3 = matrix.get(0).get(2);
            int a4 = matrix.get(1).get(0); int a5 = matrix.get(1).get(1); int a6 = matrix.get(1).get(2);
            int a7 = matrix.get(2).get(0); int a8 = matrix.get(2).get(1); int a9 = matrix.get(2).get(2);

             values = a1*(a5*a9 - a8*a6) - a2*(a4*a9 - a6*a7) + a3*(a4*a8 - a7*a5) ;
            System.out.println((float) values);
            return values;
        }
        return values;

    }

    public ArrayList<ArrayList<Float>> Inverse(ArrayList<ArrayList<Integer>> mat)
    {
        int det = Determinants(mat);

        ArrayList<ArrayList<Float>> ans = new ArrayList<>();

        int rows = mat.size();

        if(rows == 2){

            int deet = Determinants(mat);
            System.out.println((float) mat.get(1).get(1) / deet + " " + ((float) mat.get(0).get(1))*(-1)  / deet );
            System.out.println( ((float) mat.get(1).get(0))*(-1) / deet + " " + (float) mat.get(0).get(0) / deet );

        }
        else {

            for (int i = 0; i < rows; i++) {
                ArrayList<Float> kunal = new ArrayList<>();

                ans.add(i, kunal);
            }


            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 3; ++j) {

                    float k = (((float) (mat.get((j + 1) % 3).get((i + 1) % 3) * mat.get((j + 2) % 3).get((i + 2) % 3)) - (mat.get((j + 1) % 3).get((i + 2) % 3) * mat.get((j + 2) % 3).get((i + 1) % 3))) / (float) det);
                    ans.get(i).add(j, k);
                    System.out.print((((mat.get((j + 1) % 3).get((i + 1) % 3) * mat.get((j + 2) % 3).get((i + 2) % 3)) - (mat.get((j + 1) % 3).get((i + 2) % 3) * mat.get((j + 2) % 3).get((i + 1) % 3))) / det) + " ");

                }
                System.out.print("\n");
            }
        }
        return ans;


    }


    public void Transpose(ArrayList<ArrayList<Integer>> matrix ){

        for(int i =0; i< matrix.size(); i++)
        {
            for(int j =0; j<matrix.get(0).size(); j++)
            {
                System.out.print((float) matrix.get(i).get(j) + " ");
            }
            System.out.println();
        }

    }

    public void Transpose_sum(ArrayList<ArrayList<Integer>> matrix)
    {
        int rows = matrix.size();
        int column  = matrix.get(0).size();

        System.out.println("selected matrix is this: ");
        ArrayList<ArrayList<Integer>> transp = transpose(matrix);

        ArrayList<ArrayList<Integer>> answer = new ArrayList<>();

        for(int i =0; i< rows; i++)
        {
            ArrayList<Integer> temp = new ArrayList<>();
            answer.add(temp);
        }

        for(int i =0; i< rows; i++)
        {
            for(int j =0; j<column ; j++)
            {
                int kk = matrix.get(i).get(j) + transp.get(i).get(j);

                answer.get(i).add(j, kk);
            }
        }

        System.out.println("The sum is below: ");
        for(int i =0; i< rows; i++)
        {
            for(int j =0; j<column; j++)
            {
                System.out.print((float) answer.get(i).get(j) + " ");
            }
            System.out.println();
        }



    }

}

class Rectangle extends General{


}

class Singular extends  Square{

    public void Division( ArrayList<ArrayList<Integer>> mat)
    {


        System.out.println("can't dived it");

    }

}

class Ones extends  Square{

    public int Determinants(ArrayList<ArrayList<Integer>> matrix){

        System.out.println(0);
        return 0;

    }



}

class Singleton extends Square{

//    matrix m1;

}

class Null extends  General{
//    matrix m1;
public int Determinants(ArrayList<ArrayList<Integer>> matrix){
    System.out.println(0);
    return 0;

}

}

class Row extends  Rectangle{

//    matrix m1;

}

class Column extends  Rectangle{

//    matrix m1;

}

class Symmetric extends  Square{

//    matrix m1;

}

class Skew extends  Square{
//    matrix m1;
    public int Determinants(ArrayList<ArrayList<Integer>> matrix){
        ArrayList<ArrayList<Integer>> mat = m1.neo;

        int rows = mat.size();

        if(rows == 3) {


            return 0;
        }
        else{
            int a = mat.get(0).get(1);
            int b = mat.get(1).get(0);
            return a*b*(-1);
        }

    }

}

class Upper extends  Square{

    public int Determinants(ArrayList<ArrayList<Integer>> matrix){
        ArrayList<ArrayList<Integer>> mat = m1.neo;

        int rows = mat.size();

        if(rows == 3) {
            int a = mat.get(0).get(0);
            int b = mat.get(1).get(1);
            int c = mat.get(2).get(2);

            System.out.println(a * b * c);

            return a * b * c;
        }
        else{
            int a = mat.get(0).get(0);
            int b = mat.get(1).get(1);

            System.out.println(a*b);
            return a*b;
        }

    }
}

class Lower extends  Square{
    public int Determinants(ArrayList<ArrayList<Integer>> matrix){
        ArrayList<ArrayList<Integer>> mat = m1.neo;

        int rows = mat.size();

        if(rows == 3) {
            int a = mat.get(0).get(0);
            int b = mat.get(1).get(1);
            int c = mat.get(2).get(2);

            System.out.println(a * b * c);

            return a * b * c;
        }
        else{
            int a = mat.get(0).get(0);
            int b = mat.get(1).get(1);

            System.out.println(a*b);
            return a*b;
        }

    }

}

class Diagonal extends  Square{
//    matrix m1;
    public int Determinants(ArrayList<ArrayList<Integer>> matrix){
        ArrayList<ArrayList<Integer>> mat = m1.neo;

        int rows = mat.size();

        if(rows == 3) {
            int a = mat.get(0).get(0);
            int b = mat.get(1).get(1);
            int c = mat.get(2).get(2);

            System.out.println(a * b * c);

            return a * b * c;
        }
        else{
            int a = mat.get(0).get(0);
            int b = mat.get(1).get(1);

            System.out.println(a*b);
            return a*b;
        }

    }


}

class Scalar extends  Diagonal{

    public int Determinants(ArrayList<ArrayList<Integer>> matrix){
        ArrayList<ArrayList<Integer>> mat = m1.neo;

        int rows = mat.size();

        if(rows == 3) {
            int a = mat.get(0).get(0);
            System.out.println(a*a*a);

            return a * a * a;
        }
        else{
            int a = mat.get(0).get(0);


            System.out.println(a*a);
            return a*a;
        }

    }

}

class Identity extends  Scalar{

    public int Determinants(ArrayList<ArrayList<Integer>> matrix){
        System.out.println("answer is 1");
        return 1;


    }
}

