import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

class Course{

    public static void main(String[] args) throws IOException {
        Reader.init(System.in);

        Scanner sc = new Scanner(System.in);


        ArrayList<Instructor>  Instructors = new ArrayList<>();
        ArrayList<Student> Students = new ArrayList<>();

        Instructor Dumbledore = new Instructor("Dumbledore");
        Instructor Snape = new Instructor("Snape");

        Instructors.add(Dumbledore);
        Instructors.add(Snape);

        Student harry = new Student();
        harry.name("Harry");
        Student ron = new Student();
        ron.name("Ron");
        Student hermione = new Student();
        hermione.name("Hermione");

        Students.add(harry);
        Students.add(ron);
        Students.add(hermione);

        Professors_Area course1 = new Professors_Area(Instructors, Students);


        boolean get_out = false;

        while(!get_out){
            System.out.println("Welcome to Backpack\n" +
                    "1. Enter as instructor\n" +
                    "2. Enter as student\n" +
                    "3. Exit");

            int n = Reader.nextInt();

            if(n==1){

                ArrayList<Instructor> instructors = course1.instructors();
                for(int i =0; i<instructors.size(); i++)
                {
                    System.out.println(i + " - " + instructors.get(i).name());
                }

                System.out.print("Choose ID: ");
                int ints_id = Reader.nextInt();

                course1.current_prof(instructors.get(ints_id).name())  ;
                course1.curr_prof_id(ints_id);
                System.out.println("Welcome " + course1.current_prof());

                System.out.println("INSTRUCTOR MENU\n" +
                        "1. Add class material\n" +
                        "2. Add assessments\n" +
                        "3. View lecture materials\n" +
                        "4. View assessments\n" +
                        "5. Grade assessments\n" +
                        "6. Close assessment\n" +
                        "7. View comments\n" +
                        "8. Add comments\n" +
                        "9. Logout");

                boolean get_out_again = false;

                while(get_out_again == false)
                {
                    System.out.println("Welcome " + course1.current_prof());
                    System.out.println("{Instructor Menu Options}");
                    int invisible = sc.nextInt();

                    if(invisible == 9){
                        System.out.println("----------------------------");
                        break;
                    }

                    else if(invisible == 1){
                        System.out.println("1. Add Lecture Slide\n" +
                                "2. Add Lecture Video");

                        int material_option = Reader.nextInt();

                        if(material_option == 1)
                        {
                            boolean is_slides = true;
                            System.out.print("Enter topic of Slides: ");
                            String topic = Reader.nextLine();

                            System.out.print("Enter the number of slides: ");
                            int number = Reader.nextInt();

                            ArrayList<String> content = new ArrayList<>();

                            for(int i =0; i<number; i++)
                            {
                                System.out.print("Content of slide "+ (i+1) + ": ");
                                String slide_content = Reader.nextLine();

                                content.add(slide_content);
                            }
                            String file_name = "";
                            Date now = new java.util.Date();

                            course1.add_material(is_slides, content, topic, file_name, now);
                        }
                        else if(material_option == 2){
                            boolean is_slides = false;
                            System.out.print("Enter topic of Video: ");
                            String topic = Reader.nextLine();


                                ArrayList<String> content = new ArrayList<String>();


                                System.out.print("Enter the filename of Video: ");
                                String file_name = Reader.nextLine();

                                String[] exx = file_name.split("\\.");
                                if(exx.length != 2 || !exx[1].equals("mp4") ){
                                    System.out.println("Only files with .mp4 extension are accepted.");

                                } else{
                                    Date now = new java.util.Date();

                                    course1.add_material(is_slides, content, topic, file_name, now);

                                }

//                            System.out.println("************************");
                        }
                        System.out.println("----------------------------");
                    }
                    ////////////////////////////////////////////////////////////

                    else if(invisible == 2){
                        System.out.println("1. Add Assignment\n" +
                                "2. Add Quiz");

                        int choice = Reader.nextInt();

                        if(choice == 1)
                        {
                            boolean is_assignment = true;
                            System.out.print("Enter problem Statement: ");
                            String problem = Reader.nextLine();

                            System.out.print("Enter maximum marks: ");
                            int marks = Reader.nextInt();
                            Date now = new java.util.Date();

                            course1.add_assignment(problem, marks, now, is_assignment);

                        }
                        else if(choice == 2)
                        {
                            boolean is_assignment = false;
                            System.out.print("Enter quiz question: ");
                            String problem = Reader.nextLine();


                            int marks = 1;
                            Date now = new java.util.Date();
                            course1.add_assignment(problem, marks, now, is_assignment);
                        }
                        System.out.println("----------------------------");
                    }
                    //////////////////////////////////////////////////////////////////////////////
                    else if(invisible == 3){
                        course1.view_material();
                        System.out.println("----------------------------");
                    }

                    else if(invisible == 4)
                    {
                        course1.view_assesments();
                        System.out.println("----------------------------");
                    }
                    else if(invisible == 5)
                    {
                        course1.grade_assignmnet();
                        System.out.println("----------------------------");
                    }
                    else if(invisible == 6)
                    {
                        course1.close_assignmnet();
                        System.out.println("----------------------------");
                    }
                    else if(invisible == 8)
                    {
                        Date now = new java.util.Date();
                        course1.add_comments(course1.current_prof(), now );
                        System.out.println("----------------------------");
                    }
                    else if(invisible == 7)
                    {
                        course1.view_comments();
                        System.out.println("----------------------------");
                    }
                }

            }

            else if(n == 2){
                ArrayList<Student> students = course1.students();

                System.out.println("Students:");
                for(int i = 0; i<students.size(); i++)
                {
                    System.out.println("ID " + (i) + ": " +  students.get(i).name());

                }

                int choose_stud = Reader.nextInt();

                course1.curr_stud_id(choose_stud);
                course1.current_student(students.get(choose_stud).name()) ;

                System.out.println("Welcome "+ course1.current_student() );
                System.out.println("STUDENT MENU\n" +
                        "1. View lecture materials\n" +
                        "2. View assessments\n" +
                        "3. Submit assessment\n" +
                        "4. View grades\n" +
                        "5. View comments\n" +
                        "6. Add comments\n" +
                        "7. Logout");
                System.out.println("----------------------------");
                boolean seriously_get_out = false;

                while(seriously_get_out == false)
                {
                    System.out.println("Welcome " + course1.current_student());
                    System.out.println("{Students Menu}");
                    int choose_option = Reader.nextInt();

                    if(choose_option == 7)
                    {
                        seriously_get_out = true;
                        System.out.println("----------------------------");
                        break;
                    }
                    //////////////////////////
                    else if(choose_option == 1)
                    {
                        course1.view_material();
                        System.out.println("----------------------------");
                    }
                    ////////////////////////////
                    else if(choose_option == 2)
                    {
                        course1.view_assesments();
                        System.out.println("----------------------------");
                    }
                    //////////////////////////////////
                    else if(choose_option == 3){
                        students.get(choose_stud).view_assesments();
                        System.out.println("----------------------------");
                    }
                    else if(choose_option == 4)
                    {
                        students.get(choose_stud).view_grades();
                        System.out.println("----------------------------");

                    }
                    else if(choose_option == 6)
                    {
                        Date now = new java.util.Date();
                        course1.add_comments(course1.current_student(),now );
                        System.out.println("----------------------------");
                    }
                    else if(choose_option == 5)
                    {
                        course1.view_comments();
                        System.out.println("----------------------------");
                    }
                }
            }
            else if(n == 3)
            {
                System.out.println("----------------------------");
                System.out.println("The End.");
                get_out = true;
                break;
            }

        }


    }
}

class Instructor{
    private String name;
    Instructor(String name)
    {
        this.name = name;
    }

    public String name()
    {
        return this.name;
    }

}

class Student implements Professor_Students  {

    private String name;
    private ArrayList<Submissions> submissions;

    Student()
    {
        this.submissions = new ArrayList<>();
    }
    ///////////////////////////
    public ArrayList<Submissions> submissions()
    {
        return this.submissions;
    }
    public void submissions(ArrayList<Submissions> submissions)
    {
        this.submissions = submissions;
    }

    ///////////////////////
    public String name()
    {
        return this.name;
    }
    public void name(String  name)
    {
        this.name = name;
    }
    ///////////////////////



    public void view_assesments()  //adding assesment
    {
        boolean pending_assesment_checker = false;
        System.out.println("Pending Assesments:");
        for(int i =0; i<submissions.size(); i++)
        {

            Submissions each_submission = submissions.get(i);

            boolean is_assignment = each_submission.assignment().is_assignment();
            boolean is_closed = each_submission.is_closed();

            if(is_closed == false) {
                if (each_submission.is_submitted() == false) {
                    pending_assesment_checker = true;
                    if (each_submission.assignment().is_closed() == false) {

                        if (is_assignment) {
                            System.out.println("ID " + (i) + " " + "Assignment: " + each_submission.assignment().problem_statement() + " Max marks " + each_submission.assignment().max_marks());
                        } else {
                            System.out.println("ID " + (i) + " " + "Quiz: " + each_submission.assignment().problem_statement());
                        }
                    }
                }
            }
        }

        if(pending_assesment_checker== true) {


            System.out.print("Enter assesment ID: ");
            Scanner sc = new Scanner(System.in);

            String nn = sc.nextLine();
            int n = Integer.parseInt(nn);

            Submissions selected = submissions.get(n);

            if (selected.is_assignment()) {
                System.out.print("Enter the filename of Assignment: ");
                String file_namee = sc.nextLine();

                String[] exx = file_namee.split("\\.");

                if(exx.length != 2 || !exx[1].equals("zip"))
                {
                    System.out.println("only .zip files are accepted.");

                } else{
                    submissions.get(n).answer(file_namee);
                    submissions.get(n).is_submitted(true);

                }
            } else {
                System.out.print(submissions.get(n).assignment().problem_statement() + ": ");
                String ans = sc.next();

                submissions.get(n).answer(ans)  ;
                submissions.get(n).is_submitted(true)  ;
            }
        } else{
            System.out.println("No Pending Assessments");
        }
    }

    public void view_grades()
    {
        System.out.println("Graded Submissions:");

        for(int i =0; i<submissions.size(); i++)
        {
            Submissions each_submission = submissions.get(i);

            if(each_submission.is_graded()){
                System.out.println("Submission: " + each_submission.answer());
                System.out.println("Marks Scored: " + each_submission.scored_marks());
                System.out.println("Graded by " + each_submission.graded_by());

            }

        }
        System.out.println("----------------------------");
        System.out.println("Ungraded Submissions:");
        for(int i =0; i<submissions.size(); i++)
        {
            Submissions each_submission = submissions.get(i);

            if(each_submission.is_submitted() == true && each_submission.is_graded() == false){
                System.out.println("Submission: " + each_submission.answer());
            }

        }

    }


}

class Submissions{

    private int submissions_id;
    private boolean is_assignment;
    private String answer;
    private Assignments assignment;
    private int scored_marks;
    private String graded_by;
    private boolean is_graded  ;
    private boolean is_submitted  ;
    private boolean is_closed  ;
    Submissions()
    {
        this.is_graded = false;
        this.is_submitted = false;
        this.is_closed = false;
    }
    //////////////////////////////
    public int submissions_id()
    {
        return this.submissions_id;
    }
    public void submissions_id(int idfads)
    {
        this.submissions_id = idfads;
    }
    ////////////////////////////////
    public boolean is_assignment()
    {
        return this.is_assignment;
    }
    public void is_assignment(boolean asdfsdf)
    {
        this.is_assignment = asdfsdf;
    }
    //////////////////////////////
    public String answer()
    {
        return this.answer;
    }
    public void answer(String  asdfnsf)
    {
        this.answer = asdfnsf;
    }
    ///////////////////////
    public Assignments assignment()
    {
        return this.assignment;
    }
    public void assignment(Assignments asdfs)
    {
        this.assignment = asdfs;
    }
    //////////////////////////
    public int scored_marks()
    {
        return this.scored_marks;
    }
    public void scored_marks(int sdfsdf)
    {
        this.scored_marks = sdfsdf;
    }

    ///////////////////////
    public String graded_by()
    {
        return this.graded_by;
    }
    public void graded_by(String gadfs)
    {
        this.graded_by = gadfs;
    }
    ////////////////////////
    public boolean is_graded()
    {
        return this.is_graded;
    }
    public void is_graded(boolean gggggggggg)
    {
        this.is_graded = gggggggggg;
    }
    //////////////////////
    public boolean is_submitted()
    {
        return this.is_submitted;
    }
    public void is_submitted(boolean sssssssssss)
    {
        this.is_submitted = sssssssssss;
    }
    //////////////////////
    public boolean is_closed()
    {
        return this.is_closed;
    }
    public void is_closed(boolean asdfasdf)
    {
        this.is_closed = asdfasdf;
    }
//    String type;
}

interface Professor_Students{

    public void view_assesments();
}

class Professors_Area implements Professor_Students{

    Scanner sc = new Scanner(System.in);
    private ArrayList<Instructor>  instructors;
    private ArrayList<Student> students;
    private ArrayList<Material> materials = new ArrayList<Material>();
    private ArrayList<Assignments> assignments=new ArrayList<Assignments>();
    private ArrayList<Comments> comments = new ArrayList<Comments>();
    private int assignmnet_unique_id;

    Professors_Area()
    {
//        this.materials
//        this.assignments
//        this.comments
        this.assignmnet_unique_id  = 0;
    }

    private String current_prof;
    private int curr_prof_id;
    private String current_student;
    private int curr_stud_id;
    /////////////////////////////////
    public ArrayList<Student> students()
    {
        return this.students;
    }
    public void students(ArrayList<Student> students)
    {
        this.students  = students;
    }
    /////////////////////////////////
    public ArrayList<Instructor>  instructors()
    {
        return this.instructors;
    }
    public void instructors(ArrayList<Instructor>  instructors){
        this.instructors = instructors;
    }
    ////////////////////////////
    public int curr_stud_id()
    {
        return this.curr_stud_id;
    }
    public void curr_stud_id(int kdfaf)
    {
        this.curr_stud_id = kdfaf;
    }
    /////////////////////////////////
    public int curr_prof_id()
    {
        return this.curr_prof_id;
    }
    public void curr_prof_id(int k)
    {
        this.curr_prof_id = k;
    }

    /////////////////////////////
    public String  current_student()
    {
        return this.current_student;
    }
    public void current_student(String  asdfsadf)
    {
        this.current_student  = asdfsadf;
    }
    ////////////////////////////////////
    public String current_prof()
    {
        return this.current_prof;
    }
    public void current_prof(String  name)
    {
        this.current_prof = name;
    }
    ///////////////////////////////////


    Professors_Area(ArrayList<Instructor> instructors, ArrayList<Student> students){
        this.instructors = instructors;
        this.students = students;
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void add_material(boolean is_slides, ArrayList<String> slides, String topic_name, String file_name, Date noww)  {
        Material new_material = new Material();

        new_material.topic(topic_name)   ;
        new_material.uploaded_by(current_prof);
        new_material.time_of_upload(noww)  ;

        if(is_slides){
            new_material.content_slides(slides)  ;
            new_material.is_slides(true) ;

        }else{
            new_material.file_name(file_name)  ;
        }

        this.materials.add(new_material);
    }
///////////////////////////////////////////////////////////////////////////////////////////////////
    public void view_material(){

        for (Material each_materail : materials) {
            boolean is_slide = each_materail.is_slides();

            if (is_slide) {
                System.out.println("Title: " + each_materail.topic());
                ArrayList<String> slides = each_materail.content_slides();

                for (int j = 0; j < slides.size(); j++) {
                    System.out.println("Slide " + (j)+ ": " + slides.get(j));
                }

                System.out.println("Number of slides: " + slides.size());
                System.out.println("Date of Upload: " + each_materail.time_of_upload());
                System.out.println("Uploaded by: " + each_materail.uploaded_by());
                System.out.println("");

            } else{
                System.out.println("Title of Video: " + each_materail.topic());


                System.out.println("Video File: " + each_materail.file_name());
                System.out.println("Date of Upload: " + each_materail.time_of_upload());
                System.out.println("Uploaded by: " + each_materail.uploaded_by());
                System.out.println("");
            }
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////

    public void add_assignment(String problem_statement, int max_marks, Date upload_time, boolean is_assignment){

        Assignments new_assignment = new Assignments();
        new_assignment.unique_id(assignmnet_unique_id)  ;

        new_assignment.uploaded_by(current_prof)  ;
        new_assignment.problem_statement(problem_statement)  ;
        new_assignment.upload_time(upload_time) ;

        if(is_assignment) {
            new_assignment.max_marks(max_marks)  ;
            new_assignment.is_assignment(true)  ;

            for (int i =0; i<students.size(); i++) {

                Student each_student = students.get(i);
                Submissions new_sub = new Submissions();
                new_sub.assignment(new_assignment) ;
                new_sub.is_assignment(true)  ;
                new_sub.submissions_id(assignmnet_unique_id)  ;

                students.get(i).submissions().add(new_sub);
//                each_student.submissions.add(new_sub);

            }
        } else{

            new_assignment.max_marks(1) ;
            new_assignment.is_assignment(false) ;
            for (int i =0; i<students.size(); i++) {

                Student each_student = students.get(i);
                Submissions new_sub = new Submissions();
                new_sub.assignment(new_assignment)  ;
                new_sub.is_assignment(false)  ;
                new_sub.submissions_id(assignmnet_unique_id)  ;

                students.get(i).submissions().add(new_sub);
//                each_student.submissions.add(new_sub);
            }

        }

        assignments.add(new_assignment);
        assignmnet_unique_id++;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////

    public void view_assesments(){
        for(int i =0; i<assignments.size(); i++ )
        {
            Assignments each_assignment  = assignments.get(i);
            boolean is_assignment = each_assignment.is_assignment();

            if(is_assignment)
            {
                System.out.println("ID: " + i + " "+ "Assignment: " + each_assignment.problem_statement() + " Max marks: " + each_assignment.max_marks() ) ;
            }
            else
            {
                System.out.println("ID: " + i + " " +"Quiz: " + each_assignment.problem_statement() ) ;
            }
            System.out.println("------------------");
        }
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void close_assignmnet()
    {
        System.out.println("Lists of Open Assignments");
        for(int i =0; i<assignments.size(); i++)
        {
            Assignments each_assignmnet = assignments.get(i);

            if(each_assignmnet.is_closed() == false)
            {

                if(each_assignmnet.is_assignment())
                {
                    System.out.println("ID: " + i + " " + "Assignment: " + each_assignmnet.problem_statement() + " Max marks: " + each_assignmnet.max_marks() ) ;

                }
                else
                {
                    System.out.println("ID: " + i+ " " + "Quiz: " + each_assignmnet.problem_statement() ) ;
                }
                System.out.println("");
            }


        }

        System.out.println("Enter the ID of the assignment to close: ");
        int n = Integer.parseInt(sc.nextLine());
        Assignments selected_assignment = assignments.get(n);
//            assignments.get(n).is_closed = true;
        int our_id = selected_assignment.unique_id();
        for(int ii =0; ii<students.size(); ii++ )
        {
            Student each_student = students.get(ii);

            for(int j =0; j<each_student.submissions().size(); j++)
            {
                if(each_student.submissions().get(j).submissions_id() == our_id)
                {
                    students.get(ii).submissions().get(j).is_closed(true) ;
                }
            }

        }

        assignments.get(n).is_closed(true) ;

    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void grade_assignmnet(){

        System.out.println("List of Assesments");
        for(int i =0; i<assignments.size(); i++)
        {
            Assignments each_assi = assignments.get(i);

            if(each_assi.is_assignment())
            {
                System.out.println("ID: " + i+ " " + "Assignment: " + each_assi.problem_statement() + " Max marks: " + each_assi.max_marks() ) ;
            }
            else
            {
                System.out.println("ID: " + i+ " " + "Quiz: " + each_assi.problem_statement() ) ;
            }

            System.out.println("-------------------------------");

        }

        System.out.println("");

        System.out.print("Enter ID of assessment to view submissions: ");
        int nn = Integer.parseInt(sc.nextLine());

        Assignments selected_asgn = assignments.get(nn);
        int selected_id = selected_asgn.unique_id();
        System.out.println("Choose ID from these ungraded submissions: ");
        for(int j =0;j<students.size(); j++)
        {
            Student each_one = students.get(j);

            ArrayList<Submissions> their_subs = each_one.submissions();

            for(int ii =0; ii<their_subs.size(); ii++)
            {
                Submissions each_sub = their_subs.get(ii);

                if(each_sub.submissions_id() == selected_id){
                    if(each_sub.is_graded() == false)
                    {
                        System.out.println("ID " + j + ": " + each_one.name());
                    }

                }
            }
        }

        int select_student = Integer.parseInt(sc.nextLine());
        Student selected_student = students.get(select_student);

        ArrayList<Submissions> his_submissions = selected_student.submissions();

        for(int k =0; k<his_submissions.size(); k++)
        {
            Submissions each_submission = his_submissions.get(k);

            if(each_submission.submissions_id() == selected_id)
            {
                System.out.println("Submission: " + each_submission.answer()) ;
                System.out.println("----------------");
                System.out.println("Maximum Marks: " + each_submission.assignment().max_marks());

                System.out.print("Scored marks: ");
                int marks = Integer.parseInt(sc.nextLine());

                students.get(select_student).submissions().get(k).scored_marks(marks);
                students.get(select_student).submissions().get(k).is_graded(true)  ;
                students.get(select_student).submissions().get(k).graded_by(current_prof) ;


            }
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void add_comments(String name, Date timing)
    {
        System.out.print("Enter comment: ");
        String commenttt = sc.nextLine();

        Comments comment = new Comments(name, timing, commenttt);
        comments.add(comment);
    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void view_comments()
    {
        for(int i =0; i<comments.size(); i++)
        {
            System.out.println(comments.get(i).the_comment() + " - " + comments.get(i).submited_by());

            System.out.println(comments.get(i).time_stamp());
            System.out.println("");
        }
    }

}


class Material  {

    private boolean is_slides ;
    private String uploaded_by ;
    private Date time_of_upload ;
    private String topic ;
    private String file_name;
    private ArrayList<String> content_slides;
    Material(){
        this.is_slides = false;
        this.time_of_upload = null;
        this.topic = null;
        this.file_name = null;
        this.content_slides = null;
    }
    //////////////////////////////////
    public boolean is_slides()
    {
        return this.is_slides;
    }
    public void  is_slides(boolean is_slides)
    {
        this.is_slides = is_slides;
    }
    ///////////////////////////////////////////
    public String uploaded_by()
    {
        return this.uploaded_by;
    }
    public void  uploaded_by(String prof)
    {
        this.uploaded_by = prof;
    }
    ////////////////////////////////
    public Date time_of_upload()
    {
        return this.time_of_upload;
    }
    public void time_of_upload(Date now)
    {
        this.time_of_upload = now;
    }
    ///////////////////////////////////
    public String topic()
    {
        return this.topic;
    }
    public void topic(String topic)
    {
        this.topic = topic;
    }
    /////////////////////////////////////
    public String file_name()
    {
        return this.file_name;
    }
    public void file_name(String file_name)
    {
        this.file_name = file_name;
    }
    ///////////////////////////
    public ArrayList<String> content_slides()
    {
        return this.content_slides;
    }
    public void content_slides(ArrayList<String> content_slides)
    {
        this.content_slides = content_slides;
    }


}



class Assignments{

    private int unique_id;
    private boolean is_assignment;
    private String problem_statement;
    private Date upload_time;
    private boolean is_closed ;
    private int max_marks;
    private String uploaded_by;

    Assignments()
    {
        this.is_closed = false;
    }
    ///////////////////////////
    public String uploaded_by()
    {
        return this.uploaded_by;
    }
    public void  uploaded_by(String adsfsdaf)
    {
        this.uploaded_by = adsfsdaf;
    }

    //////////////////////////////
    public int max_marks()
    {
        return this.max_marks;
    }
    public void max_marks(int masdf)
    {
        this.max_marks = masdf;
    }
    //////////////////////////
    public boolean is_closed()
    {
        return this.is_closed;
    }
    public void is_closed(boolean sdf)
    {
        this.is_closed = sdf;
    }
    ///////////////////////////////
    public Date upload_time()
    {
        return this.upload_time;
    }
    public void upload_time(Date asdf){
        this.upload_time = asdf;
    }
    /////////////////////////
    public String problem_statement()
    {
        return this.problem_statement;
    }
    public void problem_statement(String adsfsdf)
    {
        this.problem_statement = adsfsdf;
    }
    ////////////////////////
    public boolean is_assignment()
    {
        return this.is_assignment;
    }
    public void is_assignment(boolean iss)
    {
        this.is_assignment = iss;
    }
    ///////////////////////
    public int unique_id()
    {
        return this.unique_id;
    }
    public void unique_id(int unid)
    {
        this.unique_id = unid;
    }

}





class Comments{
    private String submited_by;
    private Date time_stamp;
    private String the_comment;
    Comments(String name, Date time, String the_comment)
    {
        this.submited_by = name;
        this.time_stamp = time;
        this.the_comment = the_comment;
    }
    /////////////////////////////
    public String the_comment()
    {
        return this.the_comment;
    }
    public void the_comment(String qwerqwer)
    {
        this.the_comment = qwerqwer;
    }
    ////////////////////////////
    public Date time_stamp()
    {
        return this.time_stamp;
    }
    public void time_stamp(Date qwer)
    {
        this.time_stamp = qwer;
    }
    /////////////////////////////
    public String submited_by()
    {
        return this.submited_by;
    }
    public void submited_by(String asdfsd)
    {
        this.submited_by = asdfsd;
    }
    ////////////////////////////////


}



class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(
                new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer(
                    reader.readLine() );
        }
        return tokenizer.nextToken();
    }
    static String nextLine() throws IOException {
        return reader.readLine();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
}

