
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Mark1 {

    public static void main(String[] args) throws IOException {
        Reader.init(System.in);

        ArrayList<Citizens> citizenss = new ArrayList<>();
        ArrayList<Hospitals> hospitalss = new ArrayList<>();
        ArrayList<Vaccines> vacciness = new ArrayList<>();
        ArrayList<SLOT> slotss = new ArrayList<>();

        COVIN_portal taniss = new COVIN_portal(citizenss, hospitalss, vacciness, slotss);

        System.out.println("CoWin Portal initialized.... \n" +
                "--------------------------------- \n" +
                "1. Add Vaccine \n" +
                "2. Register Hospital \n" +
                "3. Register Citizen \n" +
                "4. Add Slot for Vaccination \n" +
                "5. Book Slot for Vaccination \n" +
                "6. List all slots for a hospital \n" +
                "7. Check Vaccination Status \n" +
                "8. Exit \n" +
                "--------------------------------- \n");

        boolean get_out = false;

        while(get_out != true)
        {
            System.out.println("{Menu Options}");
            int choice = Reader.nextInt();
            if(choice == 8)
            {
                System.out.println("{End of Test Case}");
                break;
            }

            else if(choice == 1){
                Vaccines new_vaccine = new Vaccines();
                System.out.print("Vaccine Name: ");
                new_vaccine.set_name(Reader.nextLine())  ;
                System.out.print("Number of Doses: ");
                new_vaccine.set_number_of_doses(Reader.nextInt())  ;
                if(new_vaccine.number_of_doses() == 1){
                    new_vaccine.set_gap_of_doses(0) ;
                } else {

                    System.out.print("Gap between Doses: ");
                    new_vaccine.set_gap_of_doses(Reader.nextInt())  ;
                }
                taniss.add_vaccines(new_vaccine);

                System.out.println("Vaccine Name: "+ new_vaccine.name() + ", Number of Doses: "+ new_vaccine.number_of_doses() + ", Gap Between Doses: "+ new_vaccine.gap_of_doses());
                System.out.println("--------------------------------- \n");
            }

            else if(choice == 2)
            {
                Hospitals new_hosp = new Hospitals();

                System.out.print("Hospital Name: ");
                new_hosp.set_name(Reader.nextLine()) ;
                System.out.print("Pincode: ");
                new_hosp.set_pincode(Reader.nextInt())  ;

                taniss.add_hospital(new_hosp);

                System.out.println("Hospital Name: "+ new_hosp.name()+ ", PinCode: "+ new_hosp.pincode() + ", Unique ID: "+ new_hosp.unique_id());
                System.out.println("--------------------------------- \n");
            }
            else if(choice == 3){

                Citizens new_citizen = new Citizens();

                System.out.print("Citizen Name: ");
                new_citizen.Setname(Reader.nextLine());

                System.out.print("Age: ");
                new_citizen.setAge(Reader.nextInt());
                System.out.print("Unique ID: ");
                new_citizen.setID(Reader.nextLine());

                if(new_citizen.age() < 19){
                    System.out.println("Only above 18 are allowed");
                }
                else{
                    taniss.add_citizen(new_citizen);
                    if(new_citizen.doses_given() == 0){
                        System.out.println("Citizen is Registered.");
                        System.out.println("Citizen Name: " + new_citizen.name() + ", Age: " + new_citizen.age() + ", Unique ID: " + new_citizen.ID());
                    }
                }

                System.out.println("--------------------------------- \n");
            }

            else if(choice == 4){
                System.out.print("Enter Hospital ID: ");
                int hosp_idd = Reader.nextInt();

                System.out.print("Enter the of slots to be added: " );
                int number = Reader.nextInt();

                for(int i =0; i<number; i++)
                {
                    System.out.print("Enter day Number: ");
                    int day_number = Reader.nextInt();
                    System.out.print("Enter Quantity: ");
                    int quantity = Reader.nextInt();
                    System.out.println("Select Vaccine");

                    ArrayList<Vaccines> list_of_vaccine = taniss.vacciness();

                    for(int ii =0; ii<list_of_vaccine.size(); ii++)
                    {
                        System.out.println(ii+ " " + list_of_vaccine.get(ii).name());
                    }

                    int select_ii = Reader.nextInt();
                    Vaccines selected_vaccine = list_of_vaccine.get(select_ii);

                    taniss.creat_slot(hosp_idd, day_number, quantity, selected_vaccine);
                    System.out.println("Slot added by Hospital "+ hosp_idd+ " for Day: "+ day_number+ ", Available Quantity: "+ quantity+ " of Vaccine "+ selected_vaccine.name());

                }
                System.out.println("--------------------------------- \n");

            }
            else if(choice == 6){
                System.out.print("Enter Hospital ID: ");
                int id = Reader.nextInt();
                String nulli = null;
                taniss.search_vaccine(id, nulli);
                System.out.println("--------------------------------- \n");
            }

            else if(choice == 5)
            {
                System.out.print("Enter patient Unique ID: ");
                String unique_id = Reader.nextLine();

                System.out.println("1. Search by area \n" +
                        "2. Search by Vaccine \n" +
                        "3. Exit\n");
                System.out.print("Enter option: ");
                int search_choice = Reader.nextInt();

                if(search_choice == 1){

                    System.out.print("Enter PinCode: ");
                    int pincode = Reader.nextInt();
                    taniss.hospitals_by_pincode(pincode);

                    System.out.print("Enter Hospital ID: ");
                    int hosp_id = Reader.nextInt();
                    String vacc_name = null;
                    taniss.search_vaccine(hosp_id, vacc_name);
                    System.out.println("Choose Slot: ");
                    int slot_choice = Reader.nextInt() ;

                    SLOT selected_slot = taniss.slotss().get(slot_choice);

                    taniss.book_slot(selected_slot, unique_id);



                } else if(search_choice == 2){
                    System.out.print("Enter vaccine name: ");
                    String vaccine_name = Reader.nextLine();

                    taniss.hospital_by_vaccine(vaccine_name);

                    System.out.print("Enter Hospital ID: ");
                    int hosp_id = Reader.nextInt();
                    taniss.search_vaccine(hosp_id, vaccine_name);

                    System.out.println("Choose slot: ");
//                    int slot_number = taniss.slot_by_hosp_and_vaccine(hosp_id, vaccine_name);
                    int slot_number = Reader.nextInt();
                    SLOT selected_slot = taniss.slotss().get(slot_number);

                    taniss.book_slot(selected_slot, unique_id);


                }else{
                    continue;
                }
                System.out.println("--------------------------------- \n");
            }

            else if(choice == 7)
            {
                System.out.print("Enter you Unique ID: ");
                String p_id = Reader.nextLine();

                taniss.patient_status(p_id);
                System.out.println("--------------------------------- \n");
            }
        }
    }

}

class COVIN_portal {

        private ArrayList<Citizens> citizenss;
        private ArrayList<Hospitals> hospitlss;
        private ArrayList<Vaccines> vacciness;
        private ArrayList<SLOT> slotss;

        public ArrayList<Vaccines> vacciness(){
            return vacciness;
        }
        public ArrayList<SLOT> slotss()
        {
            return slotss;
        }

        private int unique_id_generator = 100000;

        COVIN_portal(ArrayList<Citizens> citizenss, ArrayList<Hospitals> hospitlss, ArrayList<Vaccines> vacciness, ArrayList<SLOT> slotss){
            this.citizenss = citizenss;
            this.hospitlss = hospitlss;
            this.vacciness = vacciness;
            this.slotss = slotss;
        }

        public void add_citizen(Citizens citizens_x){
            citizenss.add(citizens_x);
//            citizens_x.status = "REGISTERED";
            citizens_x.setDoses_given(0);

        }

        public void add_hospital(Hospitals hospitals_x){
            hospitlss.add(hospitals_x);
            hospitals_x.set_unique_id(unique_id_generator)  ;
            this.unique_id_generator += 1;
        }

        public  void add_vaccines(Vaccines vaccine_x){
            vacciness.add(vaccine_x);
        }

        public void creat_slot(int hosp_id, int day_number, int quantity, Vaccines vacc_for_slot)
        {
            Hospitals hosp_for_slot = null;

            for(int i = 0; i<hospitlss.size(); i++){
                Hospitals each_hosps = hospitlss.get(i);

                int h_id = each_hosps.unique_id();

                if(hosp_id == h_id){
                    hosp_for_slot = each_hosps;
                    break;
                }
            }

            SLOT new_slot = new SLOT(hosp_for_slot, vacc_for_slot, day_number, quantity);
            slotss.add(new_slot);
        }

//        public void book_slot(String patient_id,  int hosp_pincode, String vacc_name, int hosp_id){
//
//            Citizens person_for_slot = null;
//
//            for(int i =0; i<citizenss.size(); i++)
//            {
//                Citizens persons = citizenss.get(i);
//                String person_id = persons.ID;
//
//                if(person_id.equals(patient_id)){
//                    person_for_slot = persons;
//                    break;
//                }
//            }
//        }
        public void book_slot(SLOT slot, String patient_id){

            Citizens patient = null;
            int patient_id_in_citizenss = -1;
            for(int i =0; i< citizenss.size(); i++)
            {
                Citizens each_citizen = citizenss.get(i);
                String id = each_citizen.ID();

                if(id.equals(patient_id))
                {
                    patient = each_citizen;
                    patient_id_in_citizenss = i;
                    break;
                }
            }
//            String status = patient.status;
            int doses_given = patient.doses_given();




            if(doses_given == 0){



                 if(slot.quantity() > 0){

//                        citizenss.get(patient_id_in_citizenss).doses_given +=1;

                        int x = citizenss.get(patient_id_in_citizenss).doses_given() +1;
                        citizenss.get(patient_id_in_citizenss).setDoses_given(x);

//                        patient.doses_given += 1;

                        patient.set_my_slot(slot);
                        System.out.println(patient.name() + " is vaccinated with " + slot.vaccineee().name());

                        int xx = slot.quantity() -1;
                        slot.set_quantity(xx) ;
                        if(citizenss.get(patient_id_in_citizenss).doses_given() == patient.my_slot().vaccineee().number_of_doses()){

                            citizenss.get(patient_id_in_citizenss).set_fully_vaccinated(true);


                        }

                } else{
                     System.out.println("Sorry! No slots Available");
                 }
            }
            else if (  doses_given > 0 ) {
                int doses_needed = patient.my_slot().vaccineee().number_of_doses();

                if (doses_given < doses_needed) {

                    int current_date = slot.day_number();
                    int patient_due_date = patient.my_slot().due_day();

                    if (patient_due_date > current_date) {
                        System.out.println("Your due date is on " + patient_due_date);
                        System.out.println("No slots Available.");
                    } else {
                        if (slot.quantity() > 0) {
                            if (slot.vaccineee().name().equals(patient.my_slot().vaccineee().name())) {
//                            patient.status = "FULLY VACCINATED";
//                                patient.doses_given += 1;

                                int x = citizenss.get(patient_id_in_citizenss).doses_given() +1;
                                citizenss.get(patient_id_in_citizenss).setDoses_given(x);

//                                citizenss.get(patient_id_in_citizenss).doses_given +=1;//*********************

                                int xx = slot.quantity() -1;

                                slot.set_quantity(xx) ;
                                if (citizenss.get(patient_id_in_citizenss).doses_given() == doses_needed) {

                                    citizenss.get(patient_id_in_citizenss).set_fully_vaccinated(true);//**********************
                                    patient.set_fully_vaccinated(true);

                                    System.out.println(patient.name() + " is now FULLY VACCINATED.");
                                } else {
                                    int patients_gap = patient.my_slot().vaccineee().gap_of_doses();
                                    int xy = citizenss.get(patient_id_in_citizenss).my_slot().due_day() + patients_gap;



                                    citizenss.get(patient_id_in_citizenss).my_slot().set_due_day(xy) ;

//                                    System.out.println("-------------");
//                                    System.out.println(doses_given);
//                                    System.out.println(doses_needed);
                                    System.out.println(patient.name() + " is now Partially Vaccinated.");
                                }
                            } else {
                                System.out.println("Not the Vaccine you choose Before.");
                            }
                        } else {
                            System.out.println("No slots available");
                        }
                    }
                } else if (doses_given == doses_needed) {
                    System.out.println("Citizen is fully Vaccinated.");
                }
            }
        }

//        public int slot_by_hosp_and_vaccine(int hosp_id, String vacc_name){
//            int slot_number = 0;
//            for(int i =0; i<slotss.size(); i++)
//            {
//                SLOT each_slot = slotss.get(i);
//
//                String vaccine = each_slot.vaccineee().name();
//                int hospital= each_slot.hospitall().unique_id();
//
//                if(vaccine.equals(vacc_name) && hospital==hosp_id){
//                    slot_number = i;
//                    break;
//                }
//            }
//            return  slot_number;
//        }

        public void search_vaccine(int hosp_id, String vacc_name){

            Hospitals hosp_slot_booking = null;

            for(int i =0; i<hospitlss.size(); i++){
                Hospitals each_hosp = hospitlss.get(i);

                int id = each_hosp.unique_id();

                if(hosp_id == id)
                {
                    hosp_slot_booking = each_hosp;
                    break;
                }
            }

            for(int i =0; i<slotss.size(); i++)
            {
                SLOT each_slot = slotss.get(i);

                Hospitals hosp_temp = each_slot.hospitall();

                if(hosp_temp == hosp_slot_booking && vacc_name == null){

//                    System.out.print(i + "-> ");
//                    System.out.print("Day: " + each_slot.day_number);
//                    System.out.print("Available QTY: " + each_slot.quantity);
//                    System.out.print("Vaccine: " + each_slot.vaccineee.name);
                    System.out.println( i + "-> " +  "Day: " + each_slot.day_number() + ", Vaccine: " + each_slot.vaccineee().name() + ", Available QTY: " + each_slot.quantity());

                } else if(hosp_temp == hosp_slot_booking){
                    if(vacc_name.equals(each_slot.vaccineee().name())){
                        System.out.println( i + "-> " +  "Day: " + each_slot.day_number() + ", Vaccine: " + each_slot.vaccineee().name() + ", Available QTY: " + each_slot.quantity());
                    }
                }
            }
        }

        public void hospital_by_vaccine(String vaccine_name){
            for(int i =0;i<slotss.size(); i++)
            {
                SLOT each_slot = slotss.get(i);

                String vacc_of_slot = each_slot.vaccineee().name();

                if(vacc_of_slot.equals(vaccine_name))
                {
                    Hospitals hosp_of_slot = each_slot.hospitall();

                    System.out.println(hosp_of_slot.unique_id() + " " + hosp_of_slot.name());

                }
            }
        }

        public void hospitals_by_pincode(int pincode){

            for(int i =0; i<hospitlss.size(); i++)
            {
                Hospitals each_hosp = hospitlss.get(i);

                int pin_hosp = each_hosp.pincode();

                if(pin_hosp == pincode){
                    System.out.println(each_hosp.unique_id() + " " + each_hosp.name());
                }
            }
        }

        public void patient_status(String patient_id)
        {
            Citizens citizen_for_status = null;
            for(int i =0; i<citizenss.size(); i++)
            {
                Citizens each_citizen = citizenss.get(i);
                String id = each_citizen.ID();

                if(patient_id.equals(id))
                {
                    citizen_for_status = each_citizen;
                    break;
                }
            }

            if(citizen_for_status.doses_given() !=0)
            {
//                String status = citizen_for_status.status;

                SLOT his_slot = citizen_for_status.my_slot();
                int doses_given = citizen_for_status.doses_given();
                boolean fully_vaccinated = citizen_for_status.fully_vaccinated();

                if(doses_given > 0 && fully_vaccinated == false){
//                    System.out.println(status);
                    System.out.println("PARTAILLY VACCINATED");
                    System.out.println("Vaccine given: " + his_slot.vaccineee().name());
                    System.out.println("Number of doses given " + doses_given  );
                    System.out.println("Next dose due date " + his_slot.due_day());
                }
                else if(fully_vaccinated == true){


                    System.out.println("FULLY VACCINATED"       );
                    System.out.println("Vaccine given: " + his_slot.vaccineee().name());
                    System.out.println("Number of doses given "+ his_slot.vaccineee().number_of_doses()  );
                }
            } else{
                System.out.println("Cititzen is REGISTERED");
            }

        }




}

class Citizens{
    private String Name;
    private int age;
    private String ID;
    private int doses_given;
    private boolean fully_vaccinated;

    private SLOT my_slot;
////////////////////
    public String name(){  return Name; }
    public void Setname(String namy){
        Name = namy;
    }
    ///////////////////////////
    public SLOT my_slot(){
        return my_slot;
    }
    public  void set_my_slot(SLOT slotty)
    {
        my_slot = slotty;
    }

    /////////////////////////////////////////
    public int age()
    {
        return age;
    }
    public void setAge(int agy)
    {
        age = agy;
    }
    //////////////////////////////////////////
    public String ID(){
        return ID;
    }
    public void setID(String idy){
        ID = idy;
    }
    ///////////////////////////////////////////
    public void setDoses_given(int given)
    {
        doses_given = given;
    }
    public int doses_given()
    {
        return doses_given;
    }
    /////////////////////////////////////////////
    public boolean fully_vaccinated(){
        return fully_vaccinated;
    }
    public void set_fully_vaccinated(boolean gogo)
    {
        fully_vaccinated = gogo;
    }
    /////////////////////////////////////////////

    Citizens()
    {
        fully_vaccinated = false;
        my_slot = null;
        doses_given = -1;
    }

}

class Hospitals{
    private String Name;
    private int Pincode;
    private int unique_id;

    public int unique_id()
    {
        return unique_id;
    }

    public void set_unique_id(int idy)
    {
        unique_id = idy;
    }

    //////////////////////////////////
    public int pincode()
    {
        return Pincode;
    }

    public void set_pincode(int pincody)
    {
        Pincode = pincody;
    }

    /////////////////////////////
    public String name()
    {
        return Name;
    }
    public void set_name(String namy)
    {
        Name = namy;
    }
//////////////////////////////////////



}

class Vaccines{
    private String name;
    private int number_of_doses;
    private int gap_of_doses;
    ///////////////////////
    public int gap_of_doses()
    {
        return gap_of_doses;
    }

    public void set_gap_of_doses(int gapy)
    {
        gap_of_doses = gapy;
    }
    ///////////////////////
    public int number_of_doses()
    {
        return number_of_doses;
    }
    public void set_number_of_doses(int dosy)
    {
        number_of_doses = dosy;
    }
    ///////////////////////////
    public String name()
    {
        return name;
    }
    public void set_name(String  namy)
    {
        name = namy;
    }

}

class SLOT{
    private Hospitals hospitall;
    private Vaccines vaccineee;
    private int day_number;
    private int quantity;
    private int due_day;
    //////////////////////

    public int due_day()
    {
        return due_day;
    }
    public void set_due_day(int daa){
        due_day = daa;
    }


    ///////////////////////////

    public int quantity()
    {
        return quantity;
    }

    public void set_quantity(int qu)
    {
        quantity = qu;
    }

    ///////////////////////////////////
    public int day_number()
    {
        return day_number;
    }
    public void set_day_number(int dayy)
    {
        day_number = dayy;
    }

    ///////////////////////////////////////
    public Vaccines vaccineee()
    {
        return vaccineee;
    }
    public void set_vaccineee(Vaccines vaccy)
    {
        vaccineee = vaccy;
    }

/////////////////////////////////////
    public Hospitals hospitall()
    {
        return hospitall;
    }
    public void set_hospitall(Hospitals hospy)
    {
        hospitall = hospy;
    }
////////////////////////////////////////////

    SLOT(Hospitals hospitall, Vaccines vaccineee, int day_number, int quantity){
        this.hospitall = hospitall;
        this.vaccineee = vaccineee;
        this.day_number = day_number;
        this.quantity = quantity;
        int gap = vaccineee.gap_of_doses();

        this.due_day = gap + day_number;

    }

}


class Reader {
    static BufferedReader reader;
    static StringTokenizer tokenizer;

    /** call this method to initialize reader for InputStream */
    static void init(InputStream input) {
        reader = new BufferedReader(
                new InputStreamReader(input) );
        tokenizer = new StringTokenizer("");
    }

    /** get next word */
    static String next() throws IOException {
        while ( ! tokenizer.hasMoreTokens() ) {
            //TODO add check for eof if necessary
            tokenizer = new StringTokenizer(
                    reader.readLine() );
        }
        return tokenizer.nextToken();
    }
    static String nextLine() throws IOException {
        return reader.readLine();
    }

    static int nextInt() throws IOException {
        return Integer.parseInt( next() );
    }

    static double nextDouble() throws IOException {
        return Double.parseDouble( next() );
    }
}

