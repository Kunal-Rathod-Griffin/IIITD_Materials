import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class Books implements  Comparable<Books>{

    private String title;
    private long isbn;
    private long barcode;
    private int rack;
    private int rack_number;

    Books(String title, long ISBN, long BAR){
        this.title = title;
        this.isbn = ISBN;
        this.barcode = BAR;
    }

    @Override
    public int compareTo(Books o) {

        int tn = o.title.compareTo(this.title);
        if(tn == 0){
            if(o.isbn == this.isbn)
            {
                if(this.barcode < o.barcode)
                {
                    return -1;
                }
                else{
                    return 1;
                }
            }
            else if (this.isbn < o.isbn) {
                return  -1;
            }
            else{
                return  1;
            }
        }
        else if(tn > 0)
        {
            return  -1;
        }
        else{
            return  1;
        }

    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of books N: ");
        int N = sc.nextInt();
        System.out.println("Enter the number of racks K:");
        int K = sc.nextInt();
        Books list[] = new Books[N];

        ArrayList<Long> barcodes  = new ArrayList<Long>();
        System.out.println("Now Enter the book details: ");
        for(int i =0; i< N; i++)
        {
            System.out.print("Book title: ");
            String title = sc.next();
            System.out.print("ISBN number (generally it's a 13 digit number): ");
            long isbn = sc.nextLong();

            System.out.print("Barcode number (generally is's a 12 digit number): ");
            boolean bar = true;
            long barcode = sc.nextLong();

            while(bar) {
                bar = false;
                for (int j = 0; j < barcodes.size(); j++) {
                    if (barcode == barcodes.get(j)) {
                        System.out.println("This barcode has already been given to another book.\n" +
                                "Please, choose another one: ");
                        bar = true;
                        barcode = sc.nextLong();
                    }
                }
            }
            barcodes.add(barcode);
            list[i] = new Books(title, isbn, barcode);
        }

        Arrays.sort(list);

        int slots = N/K;

        int slot_number = 1;
        int rack_number = 1;
        for(int k =0; k< list.length; k++)
        {


            list[k].rack = rack_number;
            list[k].rack_number = slot_number;
            slot_number++;

            if(slot_number == (slots+1) ){
                slot_number = 1;
                rack_number++;
            }

        }

        System.out.println("Below is the list of library books: ");

        for(int i =0; i<N; i++)
        {
            System.out.println(list[i].title + "- isbn: " + list[i].isbn + " barcode: " + list[i].barcode + " rack: " + list[i].rack + " slot: " + list[i].rack_number);
        }

        System.out.println("Press 'ZZ' to exit. ");
        System.out.println("Enter the details of the book you want to search: ");

        boolean k = true;
        while(k)
        {
            System.out.print("Enter name: ");
            String name = sc.next();

            if(name.equals("ZZ")) {
                k = false;
            }

            for(int i =0; i< list.length; i++)
            {
                String title = list[i].title;
                if(title.compareTo(name) == 0){
                    System.out.println(list[i].title + "- isbn: " + list[i].isbn + " barcode: " + list[i].barcode + " rack: " + list[i].rack + " slot: " + list[i].rack_number);
                }
            }
        }
    }
}

