import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

class matrix  {

    public static void printing_image(ArrayList<ArrayList<ArrayList<Integer>>> matrix)
    {

        int size = matrix.size();

        for(int i =0; i< size; i++)
        {
            for(int j =0; j< size; j++)
            {
                ArrayList<Integer> pixel = matrix.get(i).get(j);

                System.out.print(pixel);
                System.out.print("    ");
            }

            System.out.println();
        }
    }


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<Image> list = new ArrayList<>();

        System.out.println("What do you want to do?");


        int ids = 0;
        while(true) {
            System.out.println("-----------------------------------");
            System.out.println("0. Enter manually\n" +
                    "1. Make a default\n" +
                    "2. Update an image\n" +
                    "3. Display an image\n" +
                    "4. Get the NEGATIVE\n" +
                    "5. Exit\n");



            System.out.print("Enter choice: ");
            int task = sc.nextInt();
            if(task == 5)
            {
                System.out.println("Thank you!");
                break;
            }

            if(task == 0 || task == 1)
            {
                System.out.print("Enter the size of the matrix: ");
                int size = sc.nextInt();

                System.out.println("Which Image do you want to enter: \n" +
                        "0. grayscale image\n" +
                        "1. color image\n");
                System.out.print("Select the type: ");
                int choice = sc.nextInt();

                Image im = new Image();
                im.choice = choice;
                im.id = ids;
                ids++;
                int adder = 1;

                System.out.println("#### ID OF THIS MATRIX IS  " + im.id + " #####");

                for(int i =0; i< size; i++)
                {
                    ArrayList<ArrayList<Integer>> inti = new ArrayList<>();
                    im.matrix.add(inti);

                    for(int j =0;j < size; j++)
                    {
                        ArrayList<Integer> intit = new ArrayList<>();
                        im.matrix.get(i).add(intit);
                    }
                }

                for(int i =0; i< size; i++)
                {
                    for(int j = 0; j<size; j++)
                    {


                        if(choice == 0)
                        {

                            if(task == 0) {
                                System.out.print("Enter element of row " + i + ", column " + j + ":");
                                int s = sc.nextInt();
                                im.matrix.get(i).get(j).add(s);
                            } else{
                                im.matrix.get(i).get(j).add(adder);
                                adder++;
                            }
                        }
                        if(choice == 1)
                        {
                            for(int ii =0; ii< 3; ii++)
                            {
                                if(task == 0) {
                                    System.out.print("Enter element of row " + i + ", column " + j + ", color " + ii+": " );
                                    int m = sc.nextInt();
                                    im.matrix.get(i).get(j).add(ii, m);
                                } else{
                                    im.matrix.get(i).get(j).add(ii, adder);
                                    adder++;
                                }
                            }
                        }
                    }
                }

                list.add(im);
                adder = 1;
            }
            else if(task == 3)
            {
                System.out.print("Enter the id of the matrix: ");
                int n = sc.nextInt();

                Image im = list.get(n);

                printing_image(im.matrix);

            }
            else if(task == 2)
            {
                System.out.print("Enter the matrix number you want to update: ");
                int n = sc.nextInt();

                Image im = list.get(n);

                System.out.println("00 01 02\n" +
                        "10 11 12\n" +
                        "20 21 22\n");
                System.out.println("Enter the row number and column number according to above formate: ");
                System.out.print("Enter row: ");
                int row = sc.nextInt();
                System.out.print("Enter column: ");
                int col = sc.nextInt();

                int choice = im.choice;
                if(choice == 0)
                {
                    System.out.println("Enter the new element: ");
                    int el = sc.nextInt();
                    im.matrix.get(row).get(col).remove(0);
                    im.matrix.get(row).get(col).add(0, el);
                }
                else{
                    System.out.println("Which pixel do you want to update\n" +
                            "0. Red (taylor's version)\n" +
                            "1. Green\n" +
                            "2. Blue\n");

                    int which_pixel =  sc.nextInt();
                    System.out.println("enter the new element: ");

                    int new_el = sc.nextInt();
                    im.matrix.get(row).get(col).remove(which_pixel);
                    im.matrix.get(row).get(col).add(which_pixel, new_el);
                }

                System.out.println("Updated matrix: ");
                printing_image(im.matrix);

            }
            else if(task == 4)
            {
                ArrayList<ArrayList<ArrayList<Integer>>> ans = new ArrayList<>();

                System.out.println("Select the matrix: ");
                int n = sc.nextInt();

                Image im = list.get(n);

                for(int i =0; i< im.matrix.size(); i++)
                {
                    ArrayList<ArrayList<Integer>> new1 = new ArrayList<>();
                    ans.add(new1);


                    for(int j = 0; j < im.matrix.size(); j++)
                    {
                        ArrayList<Integer> new2 = new ArrayList<>();
                        ans.get(i).add(j, new2);

                    }
                }

                for(int i =0; i< im.matrix.size(); i++)
                {
                    for(int j =0; j< im.matrix.size(); j++)
                    {
                        ArrayList<Integer> pixel = im.matrix.get(i).get(j);

                        for(int k =0; k < pixel.size();k ++)
                        {
                            int new_el = 255 - pixel.get(k);
                            ans.get(i).get(j).add(k, new_el);
                        }
                    }
                }

                printing_image(ans);
            }
        }
    }

}

class Image{

    ArrayList<ArrayList<ArrayList<Integer>>> matrix;
    int id;
    int choice;
    Image()
    {
        matrix = new ArrayList<>();
    }

}