package com.IIITD_AP_KR3;

//Q1: Convert this code such that it does the same job but using the Runnable interface instead of the Thread Class


public class Main {

    public static void main(String[] args) {


        Thread t1=new Thread(new r1(1));
        Thread t2=new Thread(new r1(2));
        t1.start();
        t2.start();


    }
}



class r1 implements Runnable{
    int i;
    r1(int i){
        this.i=i;
    }
    @Override
    public void run(){
        int j=0;
        for (j=1;j<1000;j++){
            System.out.println(i);
        }
    }
}