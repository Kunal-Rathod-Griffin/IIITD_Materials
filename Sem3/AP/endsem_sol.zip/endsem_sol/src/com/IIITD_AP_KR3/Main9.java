package com.IIITD_AP_KR3;

//Q9: Create the list of 5 complex numbers (class=cmplx2) and print them all using an iterator.

import java.util.ArrayList;
import java.util.Iterator;

public class Main9 {
    public static void main(String[] args) {
        ArrayList<cmplx2> c=new ArrayList<cmplx2>(5);
        c.add(new cmplx2(4,5));
        c.add(new cmplx2(2,5));
        c.add(new cmplx2(7,5));
        c.add(new cmplx2(5,3));
        c.add(new cmplx2(8,5));

        Iterator iter = c.iterator();
        while (iter.hasNext())
            System.out.println(iter.next());
    }

}


class cmplx2{
    double re;
    double im;
    cmplx2(double re, double im){
        this.re=re;
        this.im=im;
    }

    @Override
    public String toString(){
        return String.valueOf(re)+"+"+String.valueOf(im)+"i";
    }
}