package com.IIITD_AP_KR3;

//Q8: Convert the following cmplx class into a singleton class

public class Main8 {
    public static void main(String[] args) {

        System.out.println(cmplx.get_instance(5,6));
        System.out.println(cmplx.get_instance(5,7));
    }
}

class cmplx{
    private static cmplx c;
    double re;
    double im;
    private cmplx(double re, double im){
        this.re=re;
        this.im=im;
    }
    public static cmplx get_instance(double re,double im){
        if(c==null){
            c=new cmplx(re,im);
            return c;
        }
        return c;
    }
    @Override
    public String toString(){
        return String.valueOf(re)+"+"+String.valueOf(im)+"i";
    }

}