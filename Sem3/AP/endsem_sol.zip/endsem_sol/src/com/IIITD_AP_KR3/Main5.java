package com.IIITD_AP_KR3;

//Q5: There is a null pointer error exception in this code.
// Using appropriate initialization blocks, modify the code such that null pointer exception is removed.

public class Main5 {
    static B5 b;
    int i=5;
    static{
        b=new B5();
    }
    public static void main(String[] args) {
        System.out.println(b.a.m.i);
    }
}

class A5{
    Main5 m;
    {
        m=new Main5();
    }
}

class B5 {
    {
        a=new A5();
    }
    A5 a;
}
