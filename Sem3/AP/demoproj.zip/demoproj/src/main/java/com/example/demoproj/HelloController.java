package com.example.demoproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Bounds;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import java.lang.Math;

public class HelloController {

    @FXML
    private Button bt;
    token red;
    player me;
    @FXML
    private ImageView img;
    @FXML
    private Label locval;




    @FXML
    void findloc(MouseEvent event) {
     me.ask2move(event,locval);
    }

    @FXML
    void move(ActionEvent event) {
        red.makeAmove(me,locval);
    }

    public void initialize() {
        red=new token(bt);
        me=new player();
    }

}

class token{
    public double orgx;
    public double orgy;
    public double currx;
    public double curry;
    public Button bt;
    public double dc=0;
    token(Button bt){
        Bounds bis= bt.localToScene(bt.getBoundsInLocal());
        System.out.println(bis);
        this.bt=bt;
        orgx=bis.getMinX();
        orgy=bis.getMinY();
        currx=orgx;
        curry=orgy;
    }
    void makeAmove(player p,Label locval){
        bt.setTranslateX(p.desx-orgx);
        bt.setTranslateY(p.desy-orgy);
        dc=dc+Math.sqrt((currx-p.desx)*(currx-p.desx)+(curry-p.desy)*(curry-p.desy));
        currx=p.desx;
        curry=p.desy;
        locval.setText("Distance Moved:"+String.valueOf(dc));
    }
}

class player{
    public double desx;
    public double desy;
    public void ask2move(MouseEvent event,Label locval){
        locval.setText("Move to X:"+String.valueOf(event.getSceneX())+"Y:"+String.valueOf(event.getSceneY()));
        desx=event.getSceneX();
        desy=event.getSceneY();
    }
}

